import XCTest
import UIKit
@testable import JMDownloader

private actor ConcurrencyProbe {
    var active = 0
    var maximum = 0
    func load(_ value: Int) async throws -> Int {
        active += 1; maximum = max(maximum, active)
        defer { active -= 1 }
        try await Task.sleep(for: .milliseconds(value % 3 == 0 ? 30 : 10))
        return value * 2
    }
    func peak() -> Int { maximum }
}

final class StorageAndLoadingTests: XCTestCase {
    func testBoundedLoadingPreservesOrderAndLimitsServicePressure() async throws {
        let probe = ConcurrencyProbe()
        let values = Array(0..<15)
        let result = try await ConcurrentLoad.map(values) { try await probe.load($0) }
        XCTAssertEqual(result, values.map { $0 * 2 })
        let peak = await probe.peak()
        XCTAssertEqual(peak, 3)
    }
    func testPortableSettingsRestoreWithoutOldBookmarksOrDownloadTasks() throws {
        let root = DiskStore.cache(UUID())
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        var saved = AppSnapshot()
        saved.preferences.tagBlacklist = "AI,测试"
        saved.preferences.themeColor = "绿"
        saved.preferences.storageRootBookmark = Data("oldGrant".utf8)
        saved.preferences.directoryBookmark = Data("oldPath".utf8)
        saved.libraries["test"] = Library(excluded: [Comic(id: "123", title: "excluded")], hiddenComicKeys: ["jmcomic:456"])
        saved.jobs = [DownloadJob(owner: "test", comic: Comic(id: "789", title: "temporary"))]
        let data = try JSONEncoder().encode(SettingsArchive(saved))
        try SettingsArchive.write(data, to: root)
        let backup = try XCTUnwrap(SettingsArchive.read(from: root))
        var restored = AppSnapshot()
        restored.preferences.directoryBookmark = Data("newGrant".utf8)
        backup.apply(to: &restored)
        XCTAssertEqual(restored.preferences.tagBlacklist, "AI,测试")
        XCTAssertEqual(restored.preferences.themeColor, "绿")
        XCTAssertEqual(restored.libraries["test"]?.excluded.first?.id, "123")
        XCTAssertEqual(restored.libraries["test"]?.hiddenComicKeys, ["jmcomic:456"])
        XCTAssertEqual(restored.preferences.directoryBookmark, Data("newGrant".utf8))
        XCTAssertTrue(restored.jobs.isEmpty)
        XCTAssertFalse(String(decoding: data, as: UTF8.self).contains("oldGrant"))
        XCTAssertNil(backup.preferences.storageRootBookmark)
        XCTAssertNil(backup.preferences.directoryBookmark)
    }
    @MainActor func testFixedDownloadsAndLegacyRootAreBothScanned() async throws {
        let root = DiskStore.documents.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let selection = try DownloadDirectory.select(root)
        XCTAssertThrowsError(try FixedStorage.prepare(selection))
        let setup = try FixedStorage.prepare(selection, allowAppDirectory: true)
        let destination = try DownloadDirectory.resolve(setup.downloads)
        XCTAssertEqual(destination.lastPathComponent, "downloads")
        let data = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 20, height: 20)).pdfData { $0.beginPage() }
        try data.write(to: root.appendingPathComponent("Legacy [JMComic 123].pdf"))
        try data.write(to: destination.appendingPathComponent("New [JMComic 456].pdf"))
        let result = try await DownloadCatalog.scanAll(bookmark: setup.downloads, defaultDirectory: root)
        XCTAssertEqual(result.keys, ["jmcomic:123", "jmcomic:456"])
    }
    func testBrokenSettingsBackupIsNeverOverwrittenDuringAuthorization() throws {
        let root = DiskStore.documents.appendingPathComponent(UUID().uuidString)
        let folder = root.appendingPathComponent("setting")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let file = folder.appendingPathComponent("settings.json")
        let bytes = Data("broken backup".utf8)
        try bytes.write(to: file)
        XCTAssertThrowsError(try FixedStorage.prepare(DownloadDirectory.select(root), allowAppDirectory: true))
        XCTAssertEqual(try Data(contentsOf: file), bytes)
    }
}
