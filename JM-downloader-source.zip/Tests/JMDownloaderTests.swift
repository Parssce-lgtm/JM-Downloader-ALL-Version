import XCTest
import UIKit
@testable import JMDownloader

final class JMDownloaderTests: XCTestCase {
    func testHostValidationRejectsCredentialAndPathInjection() throws {
        XCTAssertEqual(try Validation.hosts("https://example.com,api.example.org"), ["example.com", "api.example.org"])
        for host in ["http://example.com", "https://user:pass@example.com", "example.com/path", "example.com?q=x", ""] {
            XCTAssertThrowsError(try Validation.hosts(host))
        }
        XCTAssertThrowsError(try Validation.numericID("../123"))
        XCTAssertEqual(Validation.safeName("../../test"), ".._.._test")
    }
    func testProtocolMD5AndSegmentationBoundaries() {
        XCTAssertEqual(JMCrypto.md5("abc"), "900150983cd24fb0d6963f7d28e17f72")
        XCTAssertEqual(JMCrypto.strips(chapterID: 100, filename: "00001", scrambleID: 220980), 0)
        XCTAssertEqual(JMCrypto.strips(chapterID: 220980, filename: "00001", scrambleID: 220980), 10)
        for id in [268850, 421925, 421926, 999999] {
            let value = JMCrypto.strips(chapterID: id, filename: "00001", scrambleID: 220980)
            XCTAssertTrue(value >= 2 && value <= (id < 421926 ? 20 : 16) && value % 2 == 0)
        }
    }
    func testStripsCoverEveryPixelOnceWithRemainder() {
        for height in [101, 201, 2048] {
            let slices = JMCrypto.slices(height: height, count: 10)
            let source = slices.flatMap { Array($0.source..<($0.source + $0.height)) }.sorted()
            let destination = slices.flatMap { Array($0.destination..<($0.destination + $0.height)) }.sorted()
            XCTAssertEqual(source, Array(0..<height)); XCTAssertEqual(destination, source)
            XCTAssertEqual(slices.first?.source, height - height / 10 - height % 10)
        }
    }
    func testQueueRoundtripPreservesOwnershipAndExclusions() throws {
        let comic = Comic(id: "123", title: "测试", folders: ["默认收藏"])
        let job = DownloadJob(owner: "account-a", comic: comic, state: .paused, finished: [0, 3])
        var snapshot = AppSnapshot()
        snapshot.jobs = [job]
        snapshot.libraries = ["account-a": Library(favorites: [comic], excluded: [comic]), "account-b": Library()]
        let restored = try JSONDecoder().decode(AppSnapshot.self, from: JSONEncoder().encode(snapshot))
        XCTAssertEqual(restored.jobs[0].state, .paused)
        XCTAssertEqual(restored.jobs[0].finished, [0, 3])
        XCTAssertEqual(restored.jobs[0].owner, "account-a")
        XCTAssertEqual(restored.libraries["account-a"]?.excluded, [comic])
        XCTAssertEqual(restored.libraries["account-b"]?.excluded, [])
    }
    func testTransferIdentifierValidation() {
        let id = UUID()
        XCTAssertEqual(DownloadEngine.parse("\(id):42")?.1, 42)
        XCTAssertNil(DownloadEngine.parse("\(id):-1"))
        XCTAssertNil(DownloadEngine.parse("bad:3"))
    }
    func testInvalidImageFailsRatherThanSavingHTML() {
        let page = PageAsset(url: URL(string: "https://example.com/1.jpg")!, chapterID: "1", filename: "1.jpg", scrambleID: 220980)
        XCTAssertThrowsError(try ImagePipeline.decoded(Data("<html>Error</html>".utf8), page: page))
    }
    func testNativePDFExport() async throws {
        let comic = Comic(id: "123456", title: "Unit Test " + UUID().uuidString)
        let page = PageAsset(url: URL(string: "https://example.com/1.png")!, chapterID: "1", filename: "1.png", scrambleID: 220980)
        let job = DownloadJob(owner: "unit-test", comic: comic, state: .exporting, pages: [page], finished: [0])
        try FileManager.default.createDirectory(at: DiskStore.cache(job.id), withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: DiskStore.cache(job.id)) }
        let image = UIGraphicsImageRenderer(size: CGSize(width: 20, height: 30)).pngData { context in
            UIColor.orange.setFill(); context.fill(CGRect(x: 0, y: 0, width: 20, height: 30))
        }
        try image.write(to: DiskStore.raw(job.id, 0))
        let output = try await ImagePipeline.shared.export(job, bookmark: nil)
        defer { try? FileManager.default.removeItem(at: output) }
        XCTAssertEqual(CGPDFDocument(output as CFURL)?.numberOfPages, 1)
    }
}
