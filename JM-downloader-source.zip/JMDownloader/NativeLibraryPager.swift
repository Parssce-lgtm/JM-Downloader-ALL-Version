import SwiftUI
import UIKit
import Combine

// Only the tab indicator subscribes to these frame-by-frame updates. The
// SwiftUI page tree does not rebuild while the finger is moving.
@MainActor final class LibraryPagingPosition {
    let positions = CurrentValueSubject<CGFloat, Never>(1)
    func report(_ position: CGFloat) {
        let next = min(CGFloat(LibraryTab.allCases.count - 1), max(0, position))
        if abs(positions.value - next) > 0.0001 { positions.send(next) }
    }
}

struct NativeLibraryTabs: UIViewRepresentable {
    @Binding var selection: LibraryTab
    let paging: LibraryPagingPosition
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> TrackingLibraryTabs {
        let control = TrackingLibraryTabs(paging: paging)
        control.addTarget(context.coordinator, action: #selector(Coordinator.selectTab(_:)), for: .valueChanged)
        return control
    }
    func updateUIView(_ control: TrackingLibraryTabs, context: Context) {
        context.coordinator.parent = self
        control.selectedSegmentIndex = LibraryTab.allCases.firstIndex(of: selection)!
    }
    final class Coordinator: NSObject {
        var parent: NativeLibraryTabs
        init(_ parent: NativeLibraryTabs) { self.parent = parent }
        @objc func selectTab(_ control: UISegmentedControl) {
            guard LibraryTab.allCases.indices.contains(control.selectedSegmentIndex) else { return }
            parent.selection = LibraryTab.allCases[control.selectedSegmentIndex]
        }
    }
}

// Keep the native segmented control's buttons, selected traits and VoiceOver
// behavior. Its public background-image API lets our indicator move freely.
final class TrackingLibraryTabs: UISegmentedControl {
    private let indicator = CALayer()
    private var subscription: AnyCancellable?
    private var position: CGFloat = 1
    var indicatorFrame: CGRect { indicator.frame }

    init(paging: LibraryPagingPosition) {
        super.init(frame: .zero)
        for (index, tab) in LibraryTab.allCases.enumerated() {
            insertSegment(withTitle: tab.rawValue, at: index, animated: false)
        }
        accessibilityIdentifier = "libraryTabs"
        accessibilityLabel = "浏览类型"
        selectedSegmentTintColor = .clear
        let format = UIGraphicsImageRendererFormat(); format.opaque = false
        let clear = UIGraphicsImageRenderer(size: CGSize(width: 1, height: 1), format: format).image { _ in }
        let states: [UIControl.State] = [.normal, .selected, .highlighted, [.selected, .highlighted]]
        for state in states { setBackgroundImage(clear, for: state, barMetrics: .default) }
        for left in states { for right in states {
            setDividerImage(clear, forLeftSegmentState: left, rightSegmentState: right, barMetrics: .default)
        } }
        layer.insertSublayer(indicator, at: 0)
        layer.masksToBounds = true
        subscription = paging.positions.sink { [weak self] value in
            self?.position = value
            self?.drawIndicator()
        }
        updateAppearance()
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }
    override func layoutSubviews() { super.layoutSubviews(); drawIndicator() }
    override func traitCollectionDidChange(_ previous: UITraitCollection?) {
        super.traitCollectionDidChange(previous); updateAppearance()
    }
    private var traditional: Bool {
        if #available(iOS 26.0, *), !AppAppearance.forceTraditional { return false }
        return true
    }
    private func updateAppearance() {
        backgroundColor = .tertiarySystemFill
        let size = UIFont.preferredFont(forTextStyle: .subheadline).pointSize
        setTitleTextAttributes([.foregroundColor: UIColor.label, .font: UIFont.systemFont(ofSize: size, weight: .medium)], for: .normal)
        setTitleTextAttributes([.foregroundColor: UIColor.label, .font: UIFont.systemFont(ofSize: size, weight: .semibold)], for: .selected)
        drawIndicator()
    }
    private func drawIndicator() {
        guard numberOfSegments > 0 else { return }
        let inset: CGFloat = 3
        let segment = max(0, bounds.width - inset * 2) / CGFloat(numberOfSegments)
        let height = max(0, bounds.height - inset * 2)
        CATransaction.begin(); CATransaction.setDisableActions(true)
        layer.cornerRadius = traditional ? 8 : bounds.height / 2
        indicator.frame = CGRect(x: inset + position * segment, y: inset, width: segment, height: height)
        indicator.cornerRadius = traditional ? 6 : height / 2
        indicator.backgroundColor = (traitCollection.userInterfaceStyle == .dark ? UIColor(white: 0.36, alpha: 1) : UIColor.white).cgColor
        indicator.shadowColor = UIColor.black.cgColor; indicator.shadowOpacity = traditional ? 0.12 : 0
        indicator.shadowRadius = 2; indicator.shadowOffset = CGSize(width: 0, height: 1)
        CATransaction.commit()
    }
}

/// Native paging keeps both pages under the finger throughout a drag. Each
/// hosting view owns a full viewport without adding another safe-area inset.
struct NativeLibraryPager: UIViewControllerRepresentable {
    @Binding var selection: LibraryTab
    let paging: LibraryPagingPosition
    let animated: Bool
    let pages: [AnyView]

    func makeUIViewController(context: Context) -> LibraryPagerController {
        let controller = LibraryPagerController()
        configure(controller)
        return controller
    }
    func updateUIViewController(_ controller: LibraryPagerController, context: Context) { configure(controller) }
    private func configure(_ controller: LibraryPagerController) {
        controller.onPosition = { paging.report($0) }
        controller.onSelection = { index in
            let next = LibraryTab.allCases[index]
            if selection != next { selection = next }
        }
        controller.update(pages: pages, selectedIndex: LibraryTab.allCases.firstIndex(of: selection)!, animated: animated)
    }
}

final class LibraryPagerController: UIViewController, UIScrollViewDelegate {
    private let scroll = UIScrollView()
    private var hosts: [UIHostingController<AnyView>] = []
    private var selectedIndex = 0
    private var lastSize: CGSize = .zero
    var onSelection: ((Int) -> Void)?
    var onPosition: (@MainActor (CGFloat) -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        scroll.backgroundColor = .clear
        scroll.isPagingEnabled = true
        scroll.isDirectionalLockEnabled = true
        scroll.showsHorizontalScrollIndicator = false
        scroll.showsVerticalScrollIndicator = false
        scroll.alwaysBounceVertical = false
        scroll.contentInsetAdjustmentBehavior = .never
        scroll.keyboardDismissMode = .onDrag
        scroll.accessibilityIdentifier = "libraryPager"
        scroll.delegate = self
        view.addSubview(scroll)
    }

    func update(pages: [AnyView], selectedIndex index: Int, animated: Bool) {
        loadViewIfNeeded()
        if hosts.isEmpty {
            for page in pages {
                let host = UIHostingController(rootView: hostingPage(page))
                if #available(iOS 16.4, *) { host.safeAreaRegions = [] }
                host.view.backgroundColor = .clear
                addChild(host)
                scroll.addSubview(host.view)
                host.didMove(toParent: self)
                hosts.append(host)
            }
        } else {
            for (host, page) in zip(hosts, pages) { host.rootView = hostingPage(page) }
        }
        let changed = selectedIndex != index
        selectedIndex = index
        updateAccessibility()
        view.setNeedsLayout()
        if changed && scroll.bounds.width > 0 && !scroll.isDragging {
            scroll.setContentOffset(CGPoint(x: CGFloat(index) * scroll.bounds.width, y: 0), animated: animated)
        }
    }

    private func hostingPage(_ page: AnyView) -> AnyView {
        if #available(iOS 16.4, *) { return page }
        return AnyView(page.ignoresSafeArea(.container))
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let size = view.bounds.size
        scroll.frame = view.bounds
        for (index, host) in hosts.enumerated() {
            host.view.frame = CGRect(x: CGFloat(index) * size.width, y: 0, width: size.width, height: size.height)
        }
        scroll.contentSize = CGSize(width: CGFloat(hosts.count) * size.width, height: size.height)
        if lastSize != size {
            lastSize = size
            if !scroll.isDragging && !scroll.isDecelerating {
                scroll.setContentOffset(CGPoint(x: CGFloat(selectedIndex) * size.width, y: 0), animated: false)
            }
        }
    }

    private func updateAccessibility() {
        for (index, host) in hosts.enumerated() {
            host.view.accessibilityElementsHidden = index != selectedIndex
            host.view.isUserInteractionEnabled = index == selectedIndex
        }
    }
    private func finishPaging() {
        guard scroll.bounds.width > 0, !hosts.isEmpty else { return }
        let index = min(hosts.count - 1, max(0, Int((scroll.contentOffset.x / scroll.bounds.width).rounded())))
        guard index != selectedIndex else { return }
        selectedIndex = index
        updateAccessibility()
        onSelection?(index)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView.bounds.width > 0, !hosts.isEmpty else { return }
        onPosition?(scrollView.contentOffset.x / scrollView.bounds.width)
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate { finishPaging() }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) { finishPaging() }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) { finishPaging() }
}
