#if DEBUG
import UIKit

extension AppStore {
    func loadUIFixture() {
        account = "preview"
        clients[account] = FixtureAPI()
        preferences.tagBlacklist = "AI"
        if ProcessInfo.processInfo.arguments.contains("--dark-fixture") { preferences.appearance = "深色" }
        let comics = [Comic(id: "10001", title: "已保存的漫画", folders: ["默认收藏"]),
                      Comic(id: "10002", title: "正在下载的漫画", folders: ["默认收藏"]),
                      Comic(id: "10003", title: "等待继续的漫画", folders: ["默认收藏"])]
        libraries[account] = Library(favorites: comics)
        jobs = [DownloadJob(owner: account, comic: comics[0], state: .completed),
                DownloadJob(owner: account, comic: comics[2], state: .paused),
                DownloadJob(owner: account, comic: comics[1], state: .downloading)]
        loadRecommendations(silently: true)
        Task {
            for (index, comic) in comics.enumerated() {
                let data = UIGraphicsImageRenderer(size: CGSize(width: 90, height: 120)).pngData { context in
                    [UIColor.systemBlue, .systemOrange, .systemGreen][index].setFill()
                    context.fill(CGRect(x: 0, y: 0, width: 90, height: 120))
                }
                try? await CoverCache.shared.insert(data, key: DownloadCatalog.key(comic))
            }
        }
    }
}
private actor FixtureAPI: ComicAPI {
    func login(username: String, password: String) async throws { }
    func favorites() async throws -> [Comic] { [] }
    func search(_ query: String, page: Int) async throws -> [Comic] {
        page == 1 ? [Comic(id: "20001", title: "主动搜索的 AI 漫画", tags: ["AI绘图"])] : []
    }
    func recommendations(from favorites: [Comic]) async throws -> [Comic] { favorites }
    func manifest(for comic: Comic) async throws -> [PageAsset] { [] }
}
#endif
