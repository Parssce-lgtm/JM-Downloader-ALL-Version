import Foundation
import CoreGraphics

enum DownloadCatalog {
    static func key(_ comic: Comic) -> String { comic.source.rawValue + ":" + comic.id }
    static func key(filename: String) -> String? {
        let name = (filename as NSString).deletingPathExtension
        guard let open = name.lastIndex(of: "["), name.hasSuffix("]") else { return nil }
        let value = String(name[name.index(after: open)..<name.index(before: name.endIndex)])
        if value.hasPrefix("JMComic "), let id = try? Validation.numericID(String(value.dropFirst(8))) { return "jmcomic:" + id }
        if value.hasPrefix("PicACG "), let id = try? PicaAPI.comicID(String(value.dropFirst(7))) { return "picacg:" + id }
        if value.count == 24, let id = try? PicaAPI.comicID(value), value.contains(where: { $0.isLetter }) { return "picacg:" + id }
        if let id = try? Validation.numericID(value) { return "jmcomic:" + id }
        return nil
    }
    static func scan(bookmark: Data?) async throws -> Set<String> {
        try await Task.detached(priority: .utility) {
            var directory = DiskStore.documents
            var scoped = false
            if let bookmark {
                var stale = false
                directory = try URL(resolvingBookmarkData: bookmark, options: [], bookmarkDataIsStale: &stale)
                scoped = directory.startAccessingSecurityScopedResource()
                guard scoped else { throw JMError.message("扫描目录需要重新授权，请在账号设置中选择下载目录。") }
            }
            defer { if scoped { directory.stopAccessingSecurityScopedResource() } }
            return try scanDirectory(directory)
        }.value
    }
    static func scanDirectory(_ directory: URL) throws -> Set<String> {
        let fm = FileManager.default
        guard fm.fileExists(atPath: directory.path) else { return [] }
        var failure: Error?
        guard let files = fm.enumerator(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants], errorHandler: { _, error in failure = error; return false }) else {
            throw JMError.message("无法读取下载目录。")
        }
        var result = Set<String>()
        for case let file as URL in files {
            try Task.checkCancellation()
            guard file.pathExtension.lowercased() == "pdf", let key = key(filename: file.lastPathComponent) else { continue }
            let attributes = try file.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
            guard attributes.isRegularFile == true, attributes.isSymbolicLink != true,
                  let pdf = CGPDFDocument(file as CFURL), pdf.numberOfPages > 0 else { continue }
            result.insert(key)
        }
        if let failure { throw failure }
        return result
    }
}
