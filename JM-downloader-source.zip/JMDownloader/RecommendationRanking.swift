import Foundation

struct RecommendationDetailUnavailable: LocalizedError {
    var errorDescription: String? { "漫画标签数据不完整，暂不参与推荐。" }
}

/// Search only retrieves candidates. Full album tags determine relevance.
enum RecommendationRanking {
    private static let generic: Set<String> = ["汉化", "漢化", "中文", "中国翻译", "中國翻譯", "全彩", "完結", "完结", "连载", "連載", "同人", "日文", "英文"]
    static func normalized(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: Locale(identifier: "en_US_POSIX"))
    }
    static func tags(_ comic: Comic) -> Set<String> {
        Set(comic.tags.map(normalized).filter { !$0.isEmpty && !generic.contains($0) })
    }
    static func blocked(_ comic: Comic, blacklist: [String]) -> Bool {
        let tokens = blacklist.map(normalized).filter { !$0.isEmpty }
        return comic.tags.contains { tag in tokens.contains { normalized(tag).contains($0) } }
    }
    static func recommendations(
        from favorites: [Comic], blacklist: [String],
        detail: @escaping @Sendable (Comic) async throws -> Comic,
        search: @escaping @Sendable (String) async throws -> [Comic]
    ) async throws -> [Comic] {
        guard !favorites.isEmpty else { return [] }
        var weights: [String: Int] = [:]
        var favoriteKeys = Set<String>()
        let unique = favorites.filter { favoriteKeys.insert(DownloadCatalog.key($0)).inserted }
        // Inspect every favorite. A removed/malformed detail must not discard other
        // valid tastes; transport and session failures still fail the refresh.
        let fullFavorites = try await ConcurrentLoad.map(unique) { comic -> Comic? in
            do { return try await detail(comic) }
            catch is RecommendationDetailUnavailable { return nil }
        }
        if fullFavorites.allSatisfy({ $0 == nil }) { throw RecommendationDetailUnavailable() }
        for full in fullFavorites.compactMap({ $0 }) {
            try Task.checkCancellation()
            // Count each tag once per favorite, so duplicate tags cannot skew taste.
            for tag in tags(full) { weights[tag, default: 0] += 1 }
        }
        let tokens = blacklist.map(normalized).filter { !$0.isEmpty }
        let seeds = weights.keys.filter { tag in !tokens.contains { tag.contains($0) } }.sorted {
            weights[$0] == weights[$1] ? $0 < $1 : weights[$0, default: 0] > weights[$1, default: 0]
        }.prefix(8)
        guard !seeds.isEmpty else { return [] }
        var seen = favoriteKeys
        var candidates: [(comic: Comic, score: Double, order: Int)] = []
        var lastError: Error?
        var retrieved = 0, verified = 0
        // Independent seed searches can fail independently. Never swallow an
        // expired session or cancellation, and report failure if every seed fails.
        let searches = try await ConcurrentLoad.map(Array(seeds)) { tag -> Result<[Comic], Error> in
            do { return .success(try await search(tag)) }
            catch is CancellationError { throw CancellationError() }
            catch JMError.authenticationExpired { throw JMError.authenticationExpired }
            catch { return .failure(error) }
        }
        var pages: [[Comic]] = []
        for result in searches {
            switch result {
            case .success(let comics): pages.append(comics)
            case .failure(let error): lastError = error
            }
        }
        if pages.isEmpty, let lastError { throw lastError }
        let uniqueCandidates = pages.flatMap { $0 }.filter { seen.insert(DownloadCatalog.key($0)).inserted }
        retrieved = uniqueCandidates.count
        let checked = try await ConcurrentLoad.map(uniqueCandidates) { candidate -> Result<Comic, Error> in
            do { return .success(try await detail(candidate)) }
            catch is CancellationError { throw CancellationError() }
            catch JMError.authenticationExpired { throw JMError.authenticationExpired }
            catch { return .failure(error) }
        }
        for (index, check) in checked.enumerated() {
            let full: Comic
            switch check {
            case .success(let comic): full = comic; verified += 1
            case .failure(let error): lastError = error; continue
            }
            try Task.checkCancellation()
            guard !blocked(full, blacklist: blacklist) else { continue }
            let allTags = tags(full)
            let matched = allTags.filter { weights[$0] != nil }.sorted {
                weights[$0] == weights[$1] ? $0 < $1 : weights[$0, default: 0] > weights[$1, default: 0]
            }
            guard !matched.isEmpty else { continue }
            let total = matched.reduce(0) { $0 + weights[$1, default: 0] }
            let score = Double(total) / sqrt(Double(max(1, allTags.count)))
            var item = full
            item.reason = "收藏标签匹配：" + matched.prefix(3).joined(separator: "、")
            candidates.append((item, score, index))
        }
        if retrieved > 0, verified == 0, let lastError { throw lastError }
        // Relevance first; equal scores keep the requested server sort order.
        return candidates.sorted { $0.score == $1.score ? $0.order < $1.order : $0.score > $1.score }.map(\.comic)
    }
}
