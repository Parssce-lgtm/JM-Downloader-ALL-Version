import Foundation
import UIKit

@MainActor
final class DownloadEngine: NSObject, URLSessionDownloadDelegate {
    static let identifier = "app.jmdownloader.background.images"
    weak var store: AppStore?
    private var session: URLSession!
    private var active: [String: URLSessionDownloadTask] = [:]
    private var preparations: [UUID: Task<Void, Never>] = [:]
    private var exports: [UUID: Task<Void, Never>] = [:]
    private var preparationIDs: [UUID: UUID] = [:]
    private var exportIDs: [UUID: UUID] = [:]
    private var restored = false
    var backgroundCompletion: (() -> Void)?

    func connect(_ store: AppStore) {
        self.store = store
        let config = URLSessionConfiguration.background(withIdentifier: Self.identifier)
        config.sessionSendsLaunchEvents = true
        config.isDiscretionary = false
        try? NetworkConfiguration.apply(store.preferences, to: config)
        session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        Task {
            for task in await session.allTasks {
                guard let transfer = task as? URLSessionDownloadTask, let key = task.taskDescription,
                      let (id, _) = Self.parse(key), let job = store.jobs.first(where: { $0.id == id }),
                      job.state == .downloading else { task.cancel(); continue }
                active[key] = transfer
            }
            restored = true
            for job in store.jobs where job.state == .preparing || job.state == .exporting {
                store.change(job.id) { $0.state = $0.pages.isEmpty ? .queued : .downloading }
            }
            pump()
        }
    }
    func pump() {
        guard restored, let store else { return }
        for job in store.jobs where job.state == .queued && preparations.isEmpty {
            guard let api = store.clients[job.owner] else { continue }
            store.change(job.id) { $0.state = .preparing; $0.message = "读取图片清单…" }
            let generation = UUID()
            preparationIDs[job.id] = generation
            preparations[job.id] = Task { [weak self] in
                defer {
                    if self?.preparationIDs[job.id] == generation {
                        self?.preparationIDs[job.id] = nil
                        self?.preparations[job.id] = nil
                        self?.pump()
                    }
                }
                do {
                    let pages = try await api.manifest(for: job.comic)
                    try Task.checkCancellation()
                    try FileManager.default.createDirectory(at: DiskStore.cache(job.id), withIntermediateDirectories: true)
                    guard store.jobs.first(where: { $0.id == job.id })?.state == .preparing else { return }
                    store.change(job.id) { $0.pages = pages; $0.state = .downloading; $0.message = "" }
                } catch is CancellationError { }
                catch { self?.fail(job.id, error) }
            }
            // Prepare one album at a time, allowing its image transfers to start promptly.
            break
        }
        let limit = max(1, min(12, store.preferences.concurrency))
        for job in store.jobs where job.state == .downloading {
            if job.finished.count == job.pages.count && !job.pages.isEmpty {
                export(job); continue
            }
            for (index, page) in job.pages.enumerated() where !job.finished.contains(index) {
                if active.count >= limit { break }
                let key = "\(job.id.uuidString):\(index)"
                if active[key] != nil { continue }
                // Adopt a completed file after a process termination between file move and state save.
                if FileManager.default.fileExists(atPath: DiskStore.raw(job.id, index).path) {
                    store.change(job.id) { $0.finished.insert(index) }; continue
                }
                var request = URLRequest(url: page.url)
                request.setValue("image/*", forHTTPHeaderField: "Accept")
                if job.comic.source == .jmcomic {
                request.setValue("com.JMComic3.app", forHTTPHeaderField: "X-Requested-With")
                request.setValue("https://\((try? Validation.hosts(store.preferences.domains).first) ?? "www.cdnhjk.net")", forHTTPHeaderField: "Referer")
                }
                let transfer = session.downloadTask(with: request)
                transfer.taskDescription = key
                active[key] = transfer
                transfer.resume()
            }
            if let updated = store.jobs.first(where: { $0.id == job.id }), updated.finished.count == updated.pages.count,
               !updated.pages.isEmpty { export(updated) }
        }
    }
    func pause(_ id: UUID, state: JobState = .paused) {
        store?.change(id) { $0.state = state }
        preparationIDs[id] = nil
        exportIDs[id] = nil
        preparations.removeValue(forKey: id)?.cancel()
        exports.removeValue(forKey: id)?.cancel()
        for (key, task) in active where key.hasPrefix(id.uuidString + ":") {
            task.cancel(); active.removeValue(forKey: key)
        }
        pump()
    }
    func resume(_ id: UUID) {
        let imageHost = try? Validation.hosts(store?.preferences.effectiveImageDomain ?? Preferences.defaultImageDomain).first
        store?.change(id) { job in
            job.finished = job.finished.filter { FileManager.default.fileExists(atPath: DiskStore.raw(id, $0).path) }
            if job.comic.source == .jmcomic, let imageHost {
                for index in job.pages.indices {
                    var url = URLComponents(url: job.pages[index].url, resolvingAgainstBaseURL: false)
                    url?.host = imageHost
                    if let updated = url?.url { job.pages[index].url = updated }
                }
            }
            job.state = job.pages.isEmpty ? .queued : .downloading; job.message = ""
        }
        pump()
    }
    private func fail(_ id: UUID, _ error: Error) {
        guard let state = store?.jobs.first(where: { $0.id == id })?.state,
              state != .paused, state != .deleted else { return }
        pause(id, state: .failed)
        let message = AppStore.friendly(error)
        store?.change(id) { $0.message = message }
        store?.log(message)
    }
    private func export(_ job: DownloadJob) {
        guard exports[job.id] == nil, let store else { return }
        store.change(job.id) { $0.state = .exporting }
        let bookmark = store.preferences.directoryBookmark
        let generation = UUID()
        exportIDs[job.id] = generation
        exports[job.id] = Task { [weak self] in
            defer {
                if self?.exportIDs[job.id] == generation {
                    self?.exportIDs[job.id] = nil
                    self?.exports[job.id] = nil
                    self?.pump()
                }
            }
            let token = UIApplication.shared.beginBackgroundTask(withName: "Export PDF") { [weak self] in
                Task { @MainActor in self?.pause(job.id) }
            }
            defer { if token != .invalid { UIApplication.shared.endBackgroundTask(token) } }
            do {
                let output = try await ImagePipeline.shared.export(job, bookmark: bookmark)
                try Task.checkCancellation()
                guard store.jobs.first(where: { $0.id == job.id })?.state == .exporting else { return }
                store.change(job.id) { $0.state = .completed; $0.output = output; $0.message = "PDF 已保存到文件 App" }
                store.log("《\(job.comic.title)》下载完成")
                try? FileManager.default.removeItem(at: DiskStore.cache(job.id))
            } catch is CancellationError { }
            catch { self?.fail(job.id, error) }
        }
    }
    nonisolated static func parse(_ key: String) -> (UUID, Int)? {
        let parts = key.split(separator: ":")
        guard parts.count == 2, let id = UUID(uuidString: String(parts[0])), let index = Int(parts[1]), index >= 0 else { return nil }
        return (id, index)
    }
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let key = downloadTask.taskDescription, let (id, index) = Self.parse(key) else { return }
        // Move before returning: URLSession removes the temporary file as soon as this callback returns.
        do {
            guard let response = downloadTask.response as? HTTPURLResponse, response.statusCode == 200 else {
                throw JMError.message("图片服务器返回错误，请重试或切换图片域名。")
            }
            try FileManager.default.createDirectory(at: DiskStore.cache(id), withIntermediateDirectories: true)
            let destination = DiskStore.raw(id, index)
            if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
            try FileManager.default.moveItem(at: location, to: destination)
            Task { @MainActor [weak self] in
                guard let self, let job = self.store?.jobs.first(where: { $0.id == id }),
                      job.state == .downloading, job.pages.indices.contains(index) else { return }
                self.store?.change(id) { $0.finished.insert(index) }
            }
        } catch {
            Task { @MainActor [weak self] in
                guard self?.active[key]?.taskIdentifier == downloadTask.taskIdentifier else { return }
                self?.fail(id, error)
            }
        }
    }
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let key = task.taskDescription, let (id, _) = Self.parse(key) else { return }
        Task { @MainActor [weak self] in
            guard let self else { return }
            // A canceled older transfer must not remove a newer retry with the same description.
            guard self.active[key]?.taskIdentifier == task.taskIdentifier else { return }
            self.active[key] = nil
            if let error, (error as NSError).code != NSURLErrorCancelled { self.fail(id, error) }
            self.pump()
        }
    }
    nonisolated func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        Task { @MainActor [weak self] in
            self?.store?.persist()
            self?.backgroundCompletion?()
            self?.backgroundCompletion = nil
        }
    }
}
