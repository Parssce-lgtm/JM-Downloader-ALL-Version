import SwiftUI
import UniformTypeIdentifiers

enum DownloadDirectory {
    struct Selection: Sendable { let bookmark: Data; let name: String }
    static func isAppDirectory(_ url: URL) -> Bool {
        let root = DiskStore.documents.resolvingSymlinksInPath().standardizedFileURL.path
        let path = url.resolvingSymlinksInPath().standardizedFileURL.path
        return path == root || path.hasPrefix(root + "/")
    }
    static func select(_ parent: URL, newFolder: String? = nil) throws -> Selection {
        let scoped = parent.startAccessingSecurityScopedResource()
        defer { if scoped { parent.stopAccessingSecurityScopedResource() } }
        guard try parent.resourceValues(forKeys: [.isDirectoryKey]).isDirectory == true else {
            throw JMError.message("请选择文件夹，不能选择 PDF 或图片文件。")
        }
        let directory: URL
        if let newFolder {
            let name = newFolder.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !name.isEmpty, name != ".", name != "..", !name.contains("/"), !name.contains("\\"),
                  !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
                throw JMError.message("请填写有效的文件夹名称，不要包含斜杠。")
            }
            directory = parent.appendingPathComponent(name, isDirectory: true)
        } else { directory = parent }
        // A picker grants access to the selected folder. Do not coordinate a write on
        // its parent directory: some File Providers wait indefinitely for that lock.
        if newFolder != nil {
            guard !FileManager.default.fileExists(atPath: directory.path) else { throw JMError.message("这个文件夹已存在，请更换名称或直接选择它。") }
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
        }
        let probe = directory.appendingPathComponent(".jm-write-check-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: probe) }
        try Data().write(to: probe, options: .withoutOverwriting)
        return Selection(bookmark: try directory.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil), name: directory.lastPathComponent)
    }

    static func resolve(_ bookmark: Data?) throws -> URL {
        guard let bookmark else { return DiskStore.documents }
        var stale = false
        return try URL(resolvingBookmarkData: bookmark, options: [], bookmarkDataIsStale: &stale)
    }
}

struct FolderPicker: UIViewControllerRepresentable {
    let initialDirectory: URL
    let onBegin: () -> Void
    let onSelected: (Result<DownloadDirectory.Selection, Error>) -> Void
    let onCancel: () -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onBegin: onBegin, onSelected: onSelected, onCancel: onCancel) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = false
        picker.directoryURL = initialDirectory
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) { }
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onBegin: () -> Void
        let onSelected: (Result<DownloadDirectory.Selection, Error>) -> Void
        let onCancel: () -> Void
        init(onBegin: @escaping () -> Void, onSelected: @escaping (Result<DownloadDirectory.Selection, Error>) -> Void, onCancel: @escaping () -> Void) { self.onBegin = onBegin; self.onSelected = onSelected; self.onCancel = onCancel }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { onCancel(); return }
            // Retain the picker grant before dismissing its controller.
            let scoped = url.startAccessingSecurityScopedResource()
            onBegin()
            Task {
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                do {
                    let selection = try await Task.detached(priority: .utility) { try DownloadDirectory.select(url) }.value
                    onSelected(.success(selection))
                } catch { onSelected(.failure(error)) }
            }
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onCancel() }
    }
}

struct DownloadDirectoryControls: View {
    @Bindable var store: AppStore
    @State private var picking = false
    @State private var busy = false
    @State private var notice = ""
    @State private var needsAuthorization = false
    @State private var feedback = 0
    private var configured: Bool { store.preferences.storageRootBookmark != nil }
    var body: some View {
        Form {
            Section("固定下载位置") {
                LabeledContent("下载目录", value: configured ? store.preferences.directoryName : "尚未授权")
                    .accessibilityIdentifier("downloadDirectoryName")
                Text("首次选择软件目录之外的文件夹，在其中自动创建 downloads 和 setting。下载位置固定，PDF 完成后才写入 downloads。")
                    .font(.caption).foregroundStyle(.secondary)
                if !configured || needsAuthorization {
                    Button(configured ? "重新授权原目录" : "首次授权外部文件夹", systemImage: "folder") { picking = true }
                        .disabled(busy).accessibilityIdentifier("chooseDownloadDirectory")
                } else {
                    Label("下载目录已固定", systemImage: "lock.fill").foregroundStyle(.secondary)
                        .accessibilityIdentifier("fixedDownloadDirectory")
                }
                Text("在系统文件页进入目标文件夹，点右上角“打开”确认。旧软件根目录的 PDF 仍会一起扫描。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("卸载后恢复") {
                Text("外部 setting 保存漫画设置、标签黑名单及外观等选项，不保存密码。重装后首次授权同一个外部文件夹即可恢复。软件根目录的 setting 只是本地副本，会随软件卸载删除。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            if busy { ProgressView("正在确认目录并恢复设置…") }
            if !notice.isEmpty { Text(notice).font(.caption).accessibilityIdentifier("directoryNotice") }
        }.navigationTitle("下载目录").navigationBarTitleDisplayMode(.inline)
            .sensoryFeedback(.success, trigger: feedback)
            .task {
                if let bookmark = store.preferences.storageRootBookmark {
                    needsAuthorization = await Task.detached(priority: .utility) {
                        guard let url = try? DownloadDirectory.resolve(bookmark) else { return true }
                        let scoped = url.startAccessingSecurityScopedResource()
                        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                        return !scoped || !FileManager.default.isWritableFile(atPath: url.path)
                    }.value
                }
            }
            .sheet(isPresented: $picking) {
                FolderPicker(initialDirectory: (try? DownloadDirectory.resolve(store.preferences.storageRootBookmark)) ?? DiskStore.documents,
                             onBegin: { busy = true; notice = ""; picking = false },
                             onSelected: { result in
                    picking = false
                    Task {
                        defer { busy = false }
                        do {
                            let selection = try result.get()
                            var allowAppDirectory = false
                            #if DEBUG
                            allowAppDirectory = ProcessInfo.processInfo.arguments.contains("--ui-fixture-v120")
                            #endif
                            try await store.configureStorage(selection, allowAppDirectory: allowAppDirectory)
                            notice = "已选择：" + store.preferences.directoryName
                            needsAuthorization = false; feedback += 1
                        } catch { notice = "目录未更改：" + AppStore.friendly(error) }
                    }
                }, onCancel: { picking = false; busy = false })
            }
    }
}
