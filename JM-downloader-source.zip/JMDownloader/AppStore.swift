import SwiftUI
import Observation

@MainActor @Observable
final class AppStore {
    static let shared = AppStore()
    var preferences = Preferences()
    var jobs: [DownloadJob] = []
    var libraries: [String: Library] = [:]
    var account = ""
    var accounts: [String] = []
    var recommendations: [Comic] = []
    var searchResults: [Comic] = []
    var logs: [LogEntry] = []
    var signingIn = false
    var refreshing = false
    var recommending = false
    var searching = false
    var alert: String?
    var clients: [String: JMAPI] = [:]
    let engine = DownloadEngine()
    private var generation = UUID()
    private var recommendationTask: Task<Void, Never>?
    private var searchTask: Task<Void, Never>?
    private var refreshTask: Task<Void, Never>?
    private var didStart = false
    private var savedAccount = ""
    private var persistenceHealthy = true
    var favorites: [Comic] { libraries[account]?.favorites ?? [] }
    var excluded: [Comic] { libraries[account]?.excluded ?? [] }
    var connected: Bool { clients[account] != nil }
    var visibleJobs: [DownloadJob] {
        jobs.filter { (account.isEmpty || $0.owner == account) && (!preferences.hideCompleted || $0.state != .completed)
            && (!preferences.hideDeleted || $0.state != .deleted) }.sorted { $0.created > $1.created }
    }
    init() {
        do {
            let data = try DiskStore.load()
            preferences = data.preferences; jobs = data.jobs; libraries = data.libraries; savedAccount = data.lastAccount
        } catch { persistenceHealthy = false; alert = "本地记录无法读取，原始文件已保留。请先备份再处理。" }
        accounts = SecureStore.accounts()
    }
    func start() {
        guard !didStart else { return }; didStart = true
        engine.connect(self)
        if preferences.remember, !savedAccount.isEmpty, let password = SecureStore.password(for: savedAccount) {
            let username = savedAccount
            Task { await login(username: username, password: password) }
        }
    }
    static func friendly(_ error: Error) -> String {
        if let error = error as? JMError { return error.localizedDescription }
        if let error = error as? URLError {
            return error.code == .timedOut ? "连接超时，请稍后重试或更换线路。" : "网络连接失败，请检查 API 域名和代理。"
        }
        return "操作未完成，请检查网络、目录授权和剩余存储空间。"
    }
    func persist() {
        guard persistenceHealthy else { return }
        do {
            try DiskStore.save(AppSnapshot(preferences: preferences, libraries: libraries, jobs: jobs,
                                           lastAccount: preferences.remember ? account : ""))
        } catch { alert = "无法保存任务记录，请检查剩余存储空间。" }
    }
    func log(_ text: String) { logs.insert(LogEntry(text: text), at: 0); if logs.count > 150 { logs.removeLast() } }
    func report(_ error: Error) { let text = Self.friendly(error); log(text); alert = text }
    func change(_ id: UUID, _ update: (inout DownloadJob) -> Void) {
        guard let index = jobs.firstIndex(where: { $0.id == id }) else { return }
        update(&jobs[index]); persist()
    }
    func login(username: String, password: String) async {
        let username = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !username.isEmpty, !password.isEmpty else { alert = "请输入账号和密码。"; return }
        guard !signingIn else { return }; signingIn = true
        defer { signingIn = false }
        do {
            let api = try JMAPI(preferences: preferences)
            try await api.login(username: username, password: password)
            generation = UUID()
            refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
            refreshing = false; recommending = false; searching = false
            clients[username] = api; account = username
            recommendations = []; searchResults = []
            if libraries[username] == nil { libraries[username] = Library() }
            if preferences.remember { try SecureStore.save(username: username, password: password) }
            else { SecureStore.remove(username) }
            accounts = SecureStore.accounts()
            persist(); log("已登录：\(username)")
            engine.pump(); refreshFavorites()
        } catch { report(error) }
    }
    func switchAccount(_ username: String) async {
        if let password = SecureStore.password(for: username) { await login(username: username, password: password) }
        else { alert = "该账号未保存密码，请手动登录。" }
    }
    func logout() {
        generation = UUID()
        refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
        for job in jobs where job.owner == account && [.queued, .preparing, .downloading, .exporting].contains(job.state) { engine.pause(job.id) }
        clients[account] = nil; account = ""; recommendations = []; searchResults = []
        refreshing = false; recommending = false; searching = false
        persist()
    }
    func refreshFavorites() {
        guard !refreshing, let api = clients[account] else { if !connected { alert = "请先在账号设置中登录。" }; return }
        refreshing = true
        let owner = account, stamp = generation
        refreshTask = Task {
            defer { if stamp == generation { refreshing = false } }
            do {
                let comics = try await api.favorites()
                try Task.checkCancellation()
                guard stamp == generation else { return }
                libraries[owner, default: Library()].favorites = comics
                persist(); log("收藏刷新完成，共 \(comics.count) 部")
                if preferences.autoDownload { enqueue(comics, automatic: true) }
            } catch is CancellationError { } catch { if stamp == generation { report(error) } }
        }
    }
    func loadRecommendations() {
        guard !recommending, let api = clients[account] else { if !connected { alert = "请先在账号设置中登录。" }; return }
        recommending = true
        let stamp = generation, seed = favorites
        recommendationTask = Task {
            defer { if stamp == generation { recommending = false } }
            do {
                let comics = try await api.recommendations(from: seed)
                try Task.checkCancellation()
                if stamp == generation { recommendations = comics; log("推荐加载完成，共 \(comics.count) 部") }
            } catch is CancellationError { } catch { if stamp == generation { report(error) } }
        }
    }
    func search(_ query: String, page: Int = 1) {
        guard let api = clients[account] else { alert = "请先在账号设置中登录。"; return }
        searchTask?.cancel(); searching = true
        let stamp = generation
        searchTask = Task {
            defer { if stamp == generation { searching = false } }
            do {
                let comics = try await api.search(query, page: page)
                try Task.checkCancellation()
                guard stamp == generation else { return }
                if page == 1 { searchResults = comics }
                else { let existing = Set(searchResults.map(\.id)); searchResults += comics.filter { !existing.contains($0.id) } }
                if comics.isEmpty { log("没有更多搜索结果") }
            } catch is CancellationError { } catch { if stamp == generation { report(error) } }
        }
    }
    func enqueue(_ comics: [Comic], automatic: Bool = false) {
        guard connected else { alert = "请先登录。"; return }
        let excludedIDs = Set(excluded.map(\.id))
        var added = 0
        for comic in comics {
            if automatic && excludedIDs.contains(comic.id) { continue }
            if let existing = jobs.first(where: { $0.owner == account && $0.comic.id == comic.id }) {
                if !automatic && [.failed, .paused, .deleted].contains(existing.state) { engine.resume(existing.id) }
                continue
            }
            jobs.append(DownloadJob(owner: account, comic: comic)); added += 1
        }
        persist(); if added > 0 { log("已加入 \(added) 个下载任务") }; engine.pump()
    }
    func exclude(_ comics: [Comic]) {
        guard !account.isEmpty else { return }
        var list = excluded
        for comic in comics {
            if !list.contains(where: { $0.id == comic.id }) { list.append(comic) }
            for job in jobs where job.owner == account && job.comic.id == comic.id && [.queued, .preparing, .downloading, .exporting].contains(job.state) {
                engine.pause(job.id)
            }
        }
        libraries[account, default: Library()].excluded = list
        persist(); log("已移入不再自动下载名单")
    }
    func restoreAutomatic(_ comic: Comic) {
        libraries[account]?.excluded.removeAll { $0.id == comic.id }; persist()
    }
    func deleteJobs(comicIDs: Set<String>) {
        for job in jobs where job.owner == account && comicIDs.contains(job.comic.id) { engine.pause(job.id, state: .deleted) }
        log("已删除所选任务，已保存的 PDF 保留")
    }
    func savePreferences(_ value: Preferences) {
        do {
            _ = try Validation.hosts(value.domains); _ = try Validation.hosts(value.imageDomain)
            try NetworkConfiguration.apply(value, to: URLSessionConfiguration.ephemeral)
            let networkChanged = preferences.domains != value.domains || preferences.imageDomain != value.imageDomain
                || preferences.proxyHost != value.proxyHost || preferences.proxyPort != value.proxyPort
            preferences = value
            if !value.remember { for name in SecureStore.accounts() { SecureStore.remove(name) }; accounts = [] }
            persist()
            if networkChanged { log("线路设置已保存；请重新登录。后台图片代理将在下次启动时更新。") }
        } catch { report(error) }
    }
}
