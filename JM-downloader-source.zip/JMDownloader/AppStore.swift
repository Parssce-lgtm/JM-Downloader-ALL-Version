import SwiftUI
import Observation

@MainActor @Observable
final class AppStore {
    static let shared: AppStore = {
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--ui-fixture-v120") { return AppStore(inMemory: true) }
        #endif
        return AppStore()
    }()
    var preferences = Preferences()
    var jobs: [DownloadJob] = []
    var libraries: [String: Library] = [:]
    var account = ""
    var accounts: [String] = []
    var recommendations: [Comic] = []
    private var recommendationID = UUID()
    var recommendationSort: RecommendationSort { preferences.recommendationOrder ?? .latest }
    var tagBlacklist: [String] {
        (preferences.tagBlacklist ?? "").replacingOccurrences(of: "，", with: ",").split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.map { String($0) }
    }
    func isBlocked(_ comic: Comic) -> Bool {
        tagBlacklist.contains { token in comic.tags.contains { $0.localizedCaseInsensitiveContains(token) } }
    }
    var searchResults: [Comic] = []
    var logs: [LogEntry] = []
    var signingIn = false
    var refreshing = false
    var recommending = false
    var searching = false
    var favoriteLoad = LibraryLoadProgress(stage: "准备加载")
    var recommendationLoad = LibraryLoadProgress(stage: "准备加载")
    var searchLoad = LibraryLoadProgress(stage: "准备搜索")
    var favoriteFailure: String?
    var recommendationFailure: String?
    var searchFailure: String?
    var alert: String?
    var clients: [String: any ComicAPI] = [:]
    var platform: ComicPlatform { preferences.selectedPlatform ?? .jmcomic }
    var displayAccount: String { ComicPlatform.username(account) }
    let engine = DownloadEngine()
    let background = BackgroundWork()
    var downloadedFiles = Set<String>()
    var scanningDownloads = false
    var scanNotice = ""
    var coverCacheRevision = 0
    var coverCacheBytes: Int64 = 0
    private var scanTask: Task<Void, Never>?
    private var scanID = UUID()
    private var renewals: [String: Task<any ComicAPI, Error>] = [:]
    private var generation = UUID()
    private var activeAccounts: [ComicPlatform: String] = [:]
    private var recommendationTask: Task<Void, Never>?
    private var searchID = UUID()
    private var searchTask: Task<Void, Never>?
    private var refreshTask: Task<Void, Never>?
    private var didStart = false
    private var savedAccount = ""
    private var persistenceHealthy = true
    @ObservationIgnored private let persistence: SnapshotPersistence
    @ObservationIgnored private var progressSaveTask: Task<Void, Never>?
    @ObservationIgnored private var progressRevision = UUID()
    @ObservationIgnored private var lastPersistenceError: String?
    var favorites: [Comic] { libraries[account]?.favorites ?? [] }
    var excluded: [Comic] { libraries[account]?.excluded ?? [] }
    func isHiddenFavorite(_ comic: Comic) -> Bool {
        libraries[account]?.hiddenComicKeys?.contains(DownloadCatalog.key(comic)) == true
    }
    func hideFavorites(_ comics: [Comic]) {
        guard !account.isEmpty else { return }
        var keys = libraries[account]?.hiddenComicKeys ?? []
        keys.formUnion(comics.map(DownloadCatalog.key))
        libraries[account, default: Library()].hiddenComicKeys = keys
        persist(); log("已隐藏漫画，可在收藏的更多菜单中查看并恢复")
    }
    func showFavorite(_ comic: Comic) {
        libraries[account]?.hiddenComicKeys?.remove(DownloadCatalog.key(comic)); persist()
    }
    func isAutomaticExcluded(_ comic: Comic, owner: String? = nil) -> Bool {
        libraries[owner ?? account]?.excluded.contains { $0.id == comic.id && $0.source == comic.source } == true
    }
    var connected: Bool { clients[account] != nil }
    var visibleJobs: [DownloadJob] {
        jobs.filter { $0.comic.source == platform && (account.isEmpty || $0.owner == account) && (!preferences.hideCompleted || $0.state != .completed)
            && (!preferences.hideDeleted || $0.state != .deleted) }.sorted {
                $0.state.sortPriority == $1.state.sortPriority ? $0.created > $1.created : $0.state.sortPriority < $1.state.sortPriority
            }
    }
    init(inMemory: Bool = false, snapshotWriter: ((AppSnapshot) throws -> Void)? = nil) {
        persistence = SnapshotPersistence(writer: snapshotWriter ?? (inMemory ? { _ in } : DiskStore.save))
        background.store = self
        if inMemory { engine.store = self; return }
        do {
            var data = try DiskStore.load()
            if data.preferences.restoreRootDirectoryDefault() { try DiskStore.save(data) }
            preferences = data.preferences; jobs = data.jobs; libraries = data.libraries; savedAccount = data.lastAccount
        } catch { persistenceHealthy = false; alert = "本地记录无法读取，原始文件已保留。请先备份再处理。" }
        accounts = SecureStore.accounts()
        if preferences.remember {
            // Show the saved bookshelf immediately. Restore validated session hosts without a login round trip.
            if savedAccount.isEmpty { savedAccount = accounts.first(where: { ComicPlatform.ofAccount($0) == platform }) ?? "" }
            account = savedAccount
            if libraries[account]?.cachedRecommendationOrder == recommendationSort { recommendations = libraries[account]?.cachedRecommendations ?? [] }
            for key in accounts {
                if let saved = SessionVault.load(key), saved.platform == ComicPlatform.ofAccount(key), let api = try? Self.client(preferences, session: saved) {
                    clients[key] = api; activeAccounts[ComicPlatform.ofAccount(key)] = key
                }
            }
        }
    }
    static func client(_ preferences: Preferences, session: ServiceSession) throws -> any ComicAPI {
        let hosts = try Validation.hosts(session.platform == .jmcomic ? preferences.effectiveJMDomains : preferences.effectivePicaDomain)
        guard hosts.contains(session.host), session.platform == .jmcomic ? !(session.cookies["AVS"] ?? "").isEmpty : !session.token.isEmpty else {
            throw JMError.authenticationExpired
        }
        return try session.platform == .jmcomic ? JMAPI(preferences: preferences, savedSession: session) : PicaAPI(preferences: preferences, savedSession: session)
    }
    func start() {
        guard !didStart else { return }; didStart = true
        #if DEBUG
        if ProcessInfo.processInfo.arguments.contains("--ui-fixture-v120") { loadUIFixture(); return }
        #endif
        scanDownloadDirectory()
        engine.connect(self)
        if connected { refreshFavorites(silently: true); loadRecommendations(silently: true); return }
        if preferences.remember, !savedAccount.isEmpty, let password = SecureStore.password(for: savedAccount) {
            preferences.selectedPlatform = ComicPlatform.ofAccount(savedAccount)
            let username = ComicPlatform.username(savedAccount)
            Task { await login(username: username, password: password, platform: ComicPlatform.ofAccount(savedAccount), silently: true) }
        }
    }
    func becameActive() {
        if !scanningDownloads { scanDownloadDirectory() }
        engine.resumeAutomatic(); engine.pump()
    }
    func isDownloaded(_ comic: Comic) -> Bool {
        downloadedFiles.contains(DownloadCatalog.key(comic)) || jobs.contains {
            $0.comic.source == comic.source && $0.comic.id == comic.id && ($0.state == .completed || $0.output != nil)
        }
    }
    func scanDownloadDirectory() {
        let stamp = UUID(); scanID = stamp
        scanningDownloads = true
        scanNotice = "正在扫描默认目录和所选目录…"
        let bookmark = preferences.directoryBookmark
        scanTask = Task {
            defer { if stamp == scanID { scanningDownloads = false } }
            do {
                let found = try await DownloadCatalog.scanAll(bookmark: bookmark)
                guard stamp == scanID else { return }
                downloadedFiles = found.keys
                scanNotice = "已识别 \(found.keys.count) 部已下载漫画" + (found.warning.map { "；" + $0 } ?? "")
            } catch { if stamp == scanID { scanNotice = "下载目录扫描未完成：" + Self.friendly(error); log(scanNotice) } }
        }
    }
    func resumeJob(_ id: UUID) {
        engine.resume(id, pumpAfter: false)
        background.beginUserWork(); engine.pump()
    }
    func startAll() {
        for job in jobs where job.comic.source == platform && (account.isEmpty || job.owner == account)
            && [.paused, .failed, .queued].contains(job.state) { engine.resume(job.id, pumpAfter: false) }
        background.beginUserWork(); engine.pump()
    }
    func pauseAll() {
        engine.pauseAll(ids: Set(jobs.filter { $0.comic.source == platform && (account.isEmpty || $0.owner == account) && ($0.state.isRunning || $0.resumeAutomatically == true) }.map(\.id)))
    }
    func updateCacheSize() async { coverCacheBytes = await CoverCache.shared.size() }
    func clearCoverCache() async {
        do {
            try await CoverCache.shared.clear()
            coverCacheRevision += 1; coverCacheBytes = 0
            log("封面缓存已清理，下载中的图片及已生成 PDF 保留。")
        } catch { report(error) }
    }
    func renewSession(_ owner: String) async throws -> any ComicAPI {
        if let renewal = renewals[owner] { return try await renewal.value }
        guard preferences.remember, let password = SecureStore.password(for: owner) else { throw JMError.authenticationExpired }
        let preferences = preferences
        let renewal = Task<any ComicAPI, Error> {
            let api: any ComicAPI = try ComicPlatform.ofAccount(owner) == .jmcomic ? JMAPI(preferences: preferences) : PicaAPI(preferences: preferences)
            try await api.login(username: ComicPlatform.username(owner), password: password)
            try Task.checkCancellation()
            if let saved = await api.savedSession() { try SessionVault.save(saved, account: owner) }
            return api
        }
        renewals[owner] = renewal
        defer { renewals[owner] = nil }
        let api = try await renewal.value
        guard clients[owner] != nil else { throw CancellationError() }
        clients[owner] = api
        return api
    }
    static func friendly(_ error: Error) -> String {
        if let error = error as? RecommendationDetailUnavailable { return error.localizedDescription }
        if let error = error as? JMError { return error.localizedDescription }
        if let error = error as? ImageHTTPError { return error.localizedDescription }
        if let error = error as? URLError { return NetworkFailure.describe(error) }
        let underlying = error as NSError
        if underlying.domain == NSCocoaErrorDomain {
            if underlying.code == CocoaError.fileWriteOutOfSpace.rawValue { return "设备剩余空间不足，请释放空间后继续；已下载图片已保留。" }
            if underlying.code == CocoaError.fileWriteNoPermission.rawValue { return "无法写入文件，请检查目录授权后重试。" }
        }
        return "操作未完成，请检查网络、目录授权和剩余存储空间。"
    }
    @discardableResult func persist() -> Bool {
        progressSaveTask?.cancel(); progressSaveTask = nil; progressRevision = UUID()
        guard persistenceHealthy else { alert = "本地记录无法读取，暂未覆盖原始文件，请先备份后处理。"; return false }
        do {
            try persistence.save(AppSnapshot(preferences: preferences, libraries: libraries, jobs: jobs,
                                           lastAccount: preferences.remember ? account : ""))
            lastPersistenceError = nil
            return true
        } catch { alert = "无法保存记录，请检查剩余存储空间。"; return false }
    }
    func log(_ text: String) { logs.insert(LogEntry(text: text), at: 0); if logs.count > 150 { logs.removeLast() } }
    func report(_ error: Error) { let text = Self.friendly(error); log(text); alert = text }
    func change(_ id: UUID, _ update: (inout DownloadJob) -> Void) {
        guard let index = jobs.firstIndex(where: { $0.id == id }) else { return }
        update(&jobs[index]); scheduleProgressSave(); background.refresh()
    }
    private func scheduleProgressSave() {
        // A fixed window (not a resetting debounce) still checkpoints continuous downloads.
        guard progressSaveTask == nil else { return }
        let revision = UUID(); progressRevision = revision
        progressSaveTask = Task { [weak self] in
            do { try await Task.sleep(for: .milliseconds(500)) } catch { return }
            guard let self, !Task.isCancelled, self.progressRevision == revision else { return }
            self.progressSaveTask = nil
            _ = await self.saveProgress(revision: revision)
        }
    }
    @discardableResult func flushProgress() async -> Bool {
        progressSaveTask?.cancel(); progressSaveTask = nil
        let revision = UUID(); progressRevision = revision
        return await saveProgress(revision: revision)
    }
    private func saveProgress(revision: UUID) async -> Bool {
        guard persistenceHealthy else { return false }
        let snapshot = AppSnapshot(preferences: preferences, libraries: libraries, jobs: jobs,
                                   lastAccount: preferences.remember ? account : "")
        do {
            try await persistence.saveInBackground(snapshot)
            if progressRevision == revision { lastPersistenceError = nil }
            return true
        } catch {
            guard progressRevision == revision else { return false }
            let message = "下载进度暂未保存，请检查剩余存储空间；已下载图片缓存会保留。"
            // Download callbacks must never repeatedly present a blocking modal.
            if lastPersistenceError != message { lastPersistenceError = message; log(message) }
            return false
        }
    }
    func login(username: String, password: String, platform requestedPlatform: ComicPlatform? = nil, silently: Bool = false) async {
        let target = requestedPlatform ?? platform
        guard target == platform else { return }
        let username = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !username.isEmpty, !password.isEmpty else { alert = "请输入账号和密码。"; return }
        guard !signingIn else { return }; signingIn = true
        defer { signingIn = false }
        do {
            let key = target.accountKey(username)
            let api: any ComicAPI
            if target == .jmcomic { api = try JMAPI(preferences: preferences) }
            else { api = try PicaAPI(preferences: preferences) }
            try await api.login(username: username, password: password)
            generation = UUID()
            refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
            refreshing = false; recommending = false; searching = false
            favoriteFailure = nil; recommendationFailure = nil; searchFailure = nil
        favoriteLoad = .init(stage: "准备加载"); recommendationLoad = .init(stage: "准备加载"); searchLoad = .init(stage: "准备搜索")
            clients[key] = api; activeAccounts[target] = key; account = key
            recommendations = []; searchResults = []
            if libraries[key] == nil { libraries[key] = Library() }
            if preferences.remember {
                try SecureStore.save(username: key, password: password)
                if let saved = await api.savedSession() { try SessionVault.save(saved, account: key) }
                for old in SecureStore.accounts() where old != key && ComicPlatform.ofAccount(old) == target { SecureStore.remove(old) }
            }
            else { SecureStore.remove(key); SessionVault.remove(key) }
            accounts = SecureStore.accounts()
            persist(); log("已登录 \(target.label)：\(username)")
            engine.pump(); refreshFavorites(silently: silently)
            loadRecommendations(silently: true)
        } catch { if silently { log(Self.friendly(error)) } else { report(error) } }
    }
    func switchPlatform(_ value: ComicPlatform) {
        guard !signingIn, value != platform else { return }
        generation = UUID()
        refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
        refreshing = false; recommending = false; searching = false
        favoriteFailure = nil; recommendationFailure = nil; searchFailure = nil
        favoriteLoad = .init(stage: "准备加载"); recommendationLoad = .init(stage: "准备加载"); searchLoad = .init(stage: "准备搜索")
        recommendations = []; searchResults = []
        preferences.selectedPlatform = value
        account = activeAccounts[value] ?? ""
        persist()
        if connected { refreshFavorites(silently: true); loadRecommendations(silently: true); return }
        if preferences.remember, let key = accounts.first(where: { ComicPlatform.ofAccount($0) == value }),
           let password = SecureStore.password(for: key) {
            Task { await login(username: ComicPlatform.username(key), password: password, platform: value) }
        }
    }
    func logout() {
        generation = UUID()
        refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
        for job in jobs where job.owner == account && [.queued, .preparing, .downloading, .exporting].contains(job.state) { engine.pause(job.id) }
        renewals[account]?.cancel(); renewals[account] = nil; SessionVault.remove(account)
        clients[account] = nil; activeAccounts[platform] = nil; account = ""; recommendations = []; searchResults = []
        refreshing = false; recommending = false; searching = false
        favoriteFailure = nil; recommendationFailure = nil; searchFailure = nil
        favoriteLoad = .init(stage: "准备加载"); recommendationLoad = .init(stage: "准备加载"); searchLoad = .init(stage: "准备搜索")
        persist()
    }
    func refreshFavorites(silently: Bool = false) {
        guard !refreshing, let api = clients[account] else { if !connected { alert = "请先在账号设置中登录。" }; return }
        // Invalidate a ranking already using old favorites. Its replacement waits
        // for this refresh, and reads the possibly renewed client afterwards.
        recommendationTask?.cancel(); recommendationID = UUID(); recommending = false
        refreshing = true; favoriteFailure = nil; favoriteLoad = .init(stage: "读取收藏分页")
        let owner = account, stamp = generation
        refreshTask = Task {
            defer { if stamp == generation { refreshing = false } }
            do {
                let comics: [Comic]
                let progress: LibraryProgressHandler = { [weak self] update in
                    await self?.updateFavoriteProgress(update, stamp: stamp)
                }
                do { comics = try await LibraryLoadDeadline.run(seconds: 180) { try await api.favorites(progress: progress) } }
                catch JMError.authenticationExpired {
                    let renewed = try await renewSession(owner)
                    comics = try await LibraryLoadDeadline.run(seconds: 180) { try await renewed.favorites(progress: progress) }
                }
                try Task.checkCancellation()
                guard stamp == generation else { return }
                libraries[owner, default: Library()].favorites = comics
                favoriteLoad = .init(stage: "收藏加载完成，共 \(comics.count) 部", fraction: 1)
                persist()
                if !recommending { loadRecommendations(silently: true) }
                if preferences.autoDownload {
                    await scanTask?.value
                    guard stamp == generation else { return }
                    enqueue(comics, automatic: true, userInitiated: !silently)
                }
            } catch is CancellationError { } catch { if stamp == generation {
                favoriteFailure = Self.friendly(error)
                if !silently { alert = favoriteFailure }
            } }
        }
    }
    func setRecommendationSort(_ sort: RecommendationSort) {
        guard sort != recommendationSort else { return }
        preferences.recommendationOrder = sort; persist()
        recommendations = []; loadRecommendations()
    }
    func loadRecommendations(silently: Bool = false) {
        guard connected else { recommendationFailure = "请先登录。"; return }
        if !refreshing, favoriteFailure != nil { refreshFavorites(silently: silently); return }
        if recommendations.isEmpty, libraries[account]?.cachedRecommendationOrder == recommendationSort {
            recommendations = libraries[account]?.cachedRecommendations ?? []
        }
        recommendationTask?.cancel()
        let requestID = UUID(); recommendationID = requestID
        let order = recommendationSort
        let preferredTags: [String] = []
        let blacklist = tagBlacklist
        recommending = true; recommendationFailure = nil; recommendationLoad = .init(stage: refreshing ? "等待收藏刷新" : "读取收藏标签")
        let stamp = generation, owner = account
        let pendingRefresh = refreshTask
        recommendationTask = Task {
            defer { if stamp == generation && requestID == recommendationID { recommending = false } }
            do {
                await pendingRefresh?.value
                try Task.checkCancellation()
                guard stamp == generation && requestID == recommendationID else { return }
                if let favoriteFailure { throw JMError.message(favoriteFailure) }
                guard let api = clients[owner] else { throw JMError.authenticationExpired }
                let seed = favorites
                let comics: [Comic]
                let progress: LibraryProgressHandler = { [weak self] update in
                    await self?.updateRecommendationProgress(update, stamp: stamp, requestID: requestID)
                }
                let results: LibraryResultsHandler = { [weak self] items in
                    await self?.showRecommendationResults(items, stamp: stamp, requestID: requestID)
                }
                do { comics = try await LibraryLoadDeadline.run(seconds: 180) {
                    try await api.recommendations(from: seed, sort: order, preferredTags: preferredTags, blacklist: blacklist, progress: progress, results: results)
                } }
                catch JMError.authenticationExpired {
                    let renewed = try await renewSession(owner)
                    comics = try await LibraryLoadDeadline.run(seconds: 180) {
                        try await renewed.recommendations(from: seed, sort: order, preferredTags: preferredTags, blacklist: blacklist, progress: progress, results: results)
                    }
                }
                try Task.checkCancellation()
                if stamp == generation && requestID == recommendationID { recommendationLoad = .init(stage: "推荐加载完成，共 \(comics.count) 部", fraction: 1); recommendations = comics; libraries[owner]?.cachedRecommendations = comics; libraries[owner]?.cachedRecommendationOrder = order; persist() }
            } catch is CancellationError { } catch { if stamp == generation && requestID == recommendationID {
                recommendationFailure = recommendationLoad.stage + "：" + Self.friendly(error)
            } }
        }
    }
    func search(_ query: String, page: Int = 1) {
        guard let api = clients[account] else { searchFailure = "请先登录。"; return }
        searchTask?.cancel(); searching = true; searchFailure = nil; searchLoad = .init(stage: "正在搜索")
        let requestID = UUID(); searchID = requestID
        if page == 1 { searchResults = [] }
        let stamp = generation, owner = account
        searchTask = Task {
            defer { if stamp == generation && requestID == searchID { searching = false } }
            do {
                let comics: [Comic]
                do { comics = try await LibraryLoadDeadline.run(seconds: 60) { try await api.search(query, page: page) } }
                catch JMError.authenticationExpired {
                    let renewed = try await renewSession(owner)
                    comics = try await LibraryLoadDeadline.run(seconds: 60) { try await renewed.search(query, page: page) }
                }
                try Task.checkCancellation()
                guard stamp == generation && requestID == searchID else { return }
                if page == 1 { searchResults = comics }
                else { let existing = Set(searchResults.map(\.id)); searchResults += comics.filter { !existing.contains($0.id) } }
                searchLoad = .init(stage: "搜索完成，共 \(searchResults.count) 部", fraction: 1)
            } catch is CancellationError { } catch { if stamp == generation && requestID == searchID {
                searchFailure = Self.friendly(error)
            } }
        }
    }
    func cancelSearch() {
        searchID = UUID(); searchTask?.cancel(); searchTask = nil
        searching = false; searchResults = []; searchFailure = nil
    }
    private func updateFavoriteProgress(_ update: LibraryLoadProgress, stamp: UUID) {
        guard stamp == generation && refreshing else { return }
        favoriteLoad = update
    }
    private func updateRecommendationProgress(_ update: LibraryLoadProgress, stamp: UUID, requestID: UUID) {
        guard stamp == generation && requestID == recommendationID && recommending else { return }
        recommendationLoad = update
    }
    private func showRecommendationResults(_ comics: [Comic], stamp: UUID, requestID: UUID) {
        guard stamp == generation && requestID == recommendationID && recommending else { return }
        recommendations = comics
    }
    func enqueue(_ comics: [Comic], automatic: Bool = false, userInitiated: Bool = true) {
        guard connected else { alert = "请先登录。"; return }
        guard !scanningDownloads else { if !automatic { log("正在扫描下载目录，请稍后再开始下载。") }; return }
        let excludedIDs = Set(excluded.map(\.id))
        var added = 0
        for comic in comics {
            if isDownloaded(comic) { continue }
            if automatic && excludedIDs.contains(comic.id) { continue }
            if let existing = jobs.first(where: { $0.owner == account && $0.comic.id == comic.id }) {
                if !automatic && [.failed, .paused, .deleted].contains(existing.state) { engine.resume(existing.id, pumpAfter: false) }
                continue
            }
            jobs.append(DownloadJob(owner: account, comic: comic)); added += 1
        }
        persist(); if added > 0 { log("已加入 \(added) 个下载任务") }
        if userInitiated { background.beginUserWork() }
        engine.pump()
    }
    func exclude(_ comics: [Comic]) {
        guard !account.isEmpty else { return }
        var list = excluded
        for comic in comics {
            if !list.contains(where: { $0.id == comic.id }) { list.append(comic) }
            for job in jobs where job.owner == account && job.comic.id == comic.id && [.queued, .preparing, .downloading, .exporting].contains(job.state) {
                engine.pause(job.id)
            }
        }
        libraries[account, default: Library()].excluded = list
        persist(); log("已移入不再自动下载名单")
    }
    func restoreAutomatic(_ comic: Comic) {
        libraries[account]?.excluded.removeAll { $0.id == comic.id }; persist()
    }
    func deleteJobs(comicIDs: Set<String>) {
        var failures = 0
        for job in jobs where job.owner == account && job.comic.source == platform && comicIDs.contains(job.comic.id) {
            engine.pause(job.id, state: .deleted, pumpAfter: false)
            do {
                let cache = DiskStore.cache(job.id)
                if FileManager.default.fileExists(atPath: cache.path) { try FileManager.default.removeItem(at: cache) }
                change(job.id) { $0.pages = []; $0.finished = []; $0.renderedPages = nil; $0.skippedPages = nil; $0.message = "" }
            } catch { failures += 1; report(error) }
        }
        engine.pump()
        log(failures == 0 ? "已删除任务及下载缓存，已保存的 PDF 保留" : "任务已删除，部分下载缓存清理失败，请重试")
    }
    @discardableResult func savePreferences(_ candidate: Preferences) -> Bool {
        do {
            var value = candidate
            value.domains = try Validation.hosts(candidate.effectiveJMDomains).joined(separator: ",")
            value.imageDomain = try Validation.hosts(candidate.effectiveImageDomain)[0]
            value.picaDomain = try Validation.hosts(candidate.effectivePicaDomain)[0]
            value.proxyHost = value.proxyHost.trimmingCharacters(in: .whitespacesAndNewlines)
            try NetworkConfiguration.apply(value, to: URLSessionConfiguration.ephemeral)
            let networkChanged = preferences.effectiveJMDomains != value.effectiveJMDomains
                || preferences.effectiveImageDomain != value.effectiveImageDomain || preferences.effectivePicaDomain != value.effectivePicaDomain
                || preferences.proxyHost != value.proxyHost || preferences.proxyPort != value.proxyPort
            guard persistenceHealthy else { throw JMError.message("本地记录无法读取，设置尚未保存。请先备份原始记录。") }
            // Commit to disk before reporting success or modifying the live settings.
            do {
                progressSaveTask?.cancel(); progressSaveTask = nil; progressRevision = UUID()
                try persistence.save(AppSnapshot(preferences: value, libraries: libraries, jobs: jobs,
                                               lastAccount: value.remember ? account : ""))
            } catch { throw JMError.message("设置未保存：无法写入设备存储，请检查剩余空间后重试。") }
            let directoryChanged = preferences.directoryBookmark != value.directoryBookmark
            preferences = value
            if directoryChanged { scanDownloadDirectory() }
            if !value.remember {
                renewals.values.forEach { $0.cancel() }; renewals.removeAll()
                for name in SecureStore.accounts() { SecureStore.remove(name); SessionVault.remove(name) }; accounts = []
            }
            alert = nil
            if networkChanged { log("线路设置已保存；请重新登录。后台图片代理将在下次启动时更新。") }
            return true
        } catch { report(error); return false }
    }
}

