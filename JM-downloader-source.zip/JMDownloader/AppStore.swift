import SwiftUI
import Observation

@MainActor @Observable
final class AppStore {
    static let shared = AppStore()
    var preferences = Preferences()
    var jobs: [DownloadJob] = []
    var libraries: [String: Library] = [:]
    var account = ""
    var accounts: [String] = []
    var recommendations: [Comic] = []
    var searchResults: [Comic] = []
    var logs: [LogEntry] = []
    var signingIn = false
    var refreshing = false
    var recommending = false
    var searching = false
    var alert: String?
    var clients: [String: any ComicAPI] = [:]
    var platform: ComicPlatform { preferences.selectedPlatform ?? .jmcomic }
    var displayAccount: String { ComicPlatform.username(account) }
    let engine = DownloadEngine()
    private var generation = UUID()
    private var activeAccounts: [ComicPlatform: String] = [:]
    private var recommendationTask: Task<Void, Never>?
    private var searchTask: Task<Void, Never>?
    private var refreshTask: Task<Void, Never>?
    private var didStart = false
    private var savedAccount = ""
    private var persistenceHealthy = true
    @ObservationIgnored private let snapshotWriter: (AppSnapshot) throws -> Void
    var favorites: [Comic] { libraries[account]?.favorites ?? [] }
    var excluded: [Comic] { libraries[account]?.excluded ?? [] }
    var connected: Bool { clients[account] != nil }
    var visibleJobs: [DownloadJob] {
        jobs.filter { $0.comic.source == platform && (account.isEmpty || $0.owner == account) && (!preferences.hideCompleted || $0.state != .completed)
            && (!preferences.hideDeleted || $0.state != .deleted) }.sorted { $0.created > $1.created }
    }
    init(inMemory: Bool = false, snapshotWriter: ((AppSnapshot) throws -> Void)? = nil) {
        if let snapshotWriter { self.snapshotWriter = snapshotWriter }
        else if inMemory { self.snapshotWriter = { _ in } }
        else { self.snapshotWriter = DiskStore.save }
        if inMemory { engine.store = self; return }
        do {
            let data = try DiskStore.load()
            preferences = data.preferences; jobs = data.jobs; libraries = data.libraries; savedAccount = data.lastAccount
        } catch { persistenceHealthy = false; alert = "本地记录无法读取，原始文件已保留。请先备份再处理。" }
        accounts = SecureStore.accounts()
    }
    func start() {
        guard !didStart else { return }; didStart = true
        engine.connect(self)
        if preferences.remember, !savedAccount.isEmpty, let password = SecureStore.password(for: savedAccount) {
            preferences.selectedPlatform = ComicPlatform.ofAccount(savedAccount)
            let username = ComicPlatform.username(savedAccount)
            Task { await login(username: username, password: password, platform: ComicPlatform.ofAccount(savedAccount)) }
        }
    }
    static func friendly(_ error: Error) -> String {
        if let error = error as? JMError { return error.localizedDescription }
        if let error = error as? URLError { return NetworkFailure.describe(error) }
        let underlying = error as NSError
        if underlying.domain == NSCocoaErrorDomain {
            if underlying.code == CocoaError.fileWriteOutOfSpace.rawValue { return "设备剩余空间不足，请释放空间后继续；已下载图片已保留。" }
            if underlying.code == CocoaError.fileWriteNoPermission.rawValue { return "无法写入文件，请检查目录授权后重试。" }
        }
        return "操作未完成，请检查网络、目录授权和剩余存储空间。"
    }
    @discardableResult func persist() -> Bool {
        guard persistenceHealthy else { alert = "本地记录无法读取，暂未覆盖原始文件，请先备份后处理。"; return false }
        do {
            try snapshotWriter(AppSnapshot(preferences: preferences, libraries: libraries, jobs: jobs,
                                           lastAccount: preferences.remember ? account : ""))
            return true
        } catch { alert = "无法保存记录，请检查剩余存储空间。"; return false }
    }
    func log(_ text: String) { logs.insert(LogEntry(text: text), at: 0); if logs.count > 150 { logs.removeLast() } }
    func report(_ error: Error) { let text = Self.friendly(error); log(text); alert = text }
    func change(_ id: UUID, _ update: (inout DownloadJob) -> Void) {
        guard let index = jobs.firstIndex(where: { $0.id == id }) else { return }
        update(&jobs[index]); persist()
    }
    func login(username: String, password: String, platform requestedPlatform: ComicPlatform? = nil) async {
        let target = requestedPlatform ?? platform
        guard target == platform else { return }
        let username = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !username.isEmpty, !password.isEmpty else { alert = "请输入账号和密码。"; return }
        guard !signingIn else { return }; signingIn = true
        defer { signingIn = false }
        do {
            let key = target.accountKey(username)
            let api: any ComicAPI
            if target == .jmcomic { api = try JMAPI(preferences: preferences) }
            else { api = try PicaAPI(preferences: preferences) }
            try await api.login(username: username, password: password)
            generation = UUID()
            refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
            refreshing = false; recommending = false; searching = false
            clients[key] = api; activeAccounts[target] = key; account = key
            recommendations = []; searchResults = []
            if libraries[key] == nil { libraries[key] = Library() }
            if preferences.remember {
                try SecureStore.save(username: key, password: password)
                for old in SecureStore.accounts() where old != key && ComicPlatform.ofAccount(old) == target { SecureStore.remove(old) }
            }
            else { SecureStore.remove(key) }
            accounts = SecureStore.accounts()
            persist(); log("已登录 \(target.label)：\(username)")
            engine.pump(); refreshFavorites()
        } catch { report(error) }
    }
    func switchPlatform(_ value: ComicPlatform) {
        guard !signingIn, value != platform else { return }
        generation = UUID()
        refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
        refreshing = false; recommending = false; searching = false
        recommendations = []; searchResults = []
        preferences.selectedPlatform = value
        account = activeAccounts[value] ?? ""
        persist()
        if connected { refreshFavorites(); return }
        if preferences.remember, let key = accounts.first(where: { ComicPlatform.ofAccount($0) == value }),
           let password = SecureStore.password(for: key) {
            Task { await login(username: ComicPlatform.username(key), password: password, platform: value) }
        }
    }
    func logout() {
        generation = UUID()
        refreshTask?.cancel(); recommendationTask?.cancel(); searchTask?.cancel()
        for job in jobs where job.owner == account && [.queued, .preparing, .downloading, .exporting].contains(job.state) { engine.pause(job.id) }
        clients[account] = nil; activeAccounts[platform] = nil; account = ""; recommendations = []; searchResults = []
        refreshing = false; recommending = false; searching = false
        persist()
    }
    func refreshFavorites() {
        guard !refreshing, let api = clients[account] else { if !connected { alert = "请先在账号设置中登录。" }; return }
        refreshing = true
        let owner = account, stamp = generation
        refreshTask = Task {
            defer { if stamp == generation { refreshing = false } }
            do {
                let comics = try await api.favorites()
                try Task.checkCancellation()
                guard stamp == generation else { return }
                libraries[owner, default: Library()].favorites = comics
                persist(); log("收藏刷新完成，共 \(comics.count) 部")
                if preferences.autoDownload { enqueue(comics, automatic: true) }
            } catch is CancellationError { } catch { if stamp == generation { report(error) } }
        }
    }
    func loadRecommendations() {
        guard !recommending, let api = clients[account] else { if !connected { alert = "请先在账号设置中登录。" }; return }
        recommending = true
        let stamp = generation, seed = favorites
        recommendationTask = Task {
            defer { if stamp == generation { recommending = false } }
            do {
                let comics = try await api.recommendations(from: seed)
                try Task.checkCancellation()
                if stamp == generation { recommendations = comics; log("推荐加载完成，共 \(comics.count) 部") }
            } catch is CancellationError { } catch { if stamp == generation { report(error) } }
        }
    }
    func search(_ query: String, page: Int = 1) {
        guard let api = clients[account] else { alert = "请先在账号设置中登录。"; return }
        searchTask?.cancel(); searching = true
        let stamp = generation
        searchTask = Task {
            defer { if stamp == generation { searching = false } }
            do {
                let comics = try await api.search(query, page: page)
                try Task.checkCancellation()
                guard stamp == generation else { return }
                if page == 1 { searchResults = comics }
                else { let existing = Set(searchResults.map(\.id)); searchResults += comics.filter { !existing.contains($0.id) } }
                if comics.isEmpty { log("没有更多搜索结果") }
            } catch is CancellationError { } catch { if stamp == generation { report(error) } }
        }
    }
    func enqueue(_ comics: [Comic], automatic: Bool = false) {
        guard connected else { alert = "请先登录。"; return }
        let excludedIDs = Set(excluded.map(\.id))
        var added = 0
        for comic in comics {
            if automatic && excludedIDs.contains(comic.id) { continue }
            if let existing = jobs.first(where: { $0.owner == account && $0.comic.id == comic.id }) {
                if !automatic && [.failed, .paused, .deleted].contains(existing.state) { engine.resume(existing.id) }
                continue
            }
            jobs.append(DownloadJob(owner: account, comic: comic)); added += 1
        }
        persist(); if added > 0 { log("已加入 \(added) 个下载任务") }; engine.pump()
    }
    func exclude(_ comics: [Comic]) {
        guard !account.isEmpty else { return }
        var list = excluded
        for comic in comics {
            if !list.contains(where: { $0.id == comic.id }) { list.append(comic) }
            for job in jobs where job.owner == account && job.comic.id == comic.id && [.queued, .preparing, .downloading, .exporting].contains(job.state) {
                engine.pause(job.id)
            }
        }
        libraries[account, default: Library()].excluded = list
        persist(); log("已移入不再自动下载名单")
    }
    func restoreAutomatic(_ comic: Comic) {
        libraries[account]?.excluded.removeAll { $0.id == comic.id }; persist()
    }
    func deleteJobs(comicIDs: Set<String>) {
        for job in jobs where job.owner == account && comicIDs.contains(job.comic.id) { engine.pause(job.id, state: .deleted) }
        log("已删除所选任务，已保存的 PDF 保留")
    }
    @discardableResult func savePreferences(_ candidate: Preferences) -> Bool {
        do {
            var value = candidate
            value.domains = try Validation.hosts(candidate.effectiveJMDomains).joined(separator: ",")
            value.imageDomain = try Validation.hosts(candidate.effectiveImageDomain)[0]
            value.picaDomain = try Validation.hosts(candidate.effectivePicaDomain)[0]
            value.proxyHost = value.proxyHost.trimmingCharacters(in: .whitespacesAndNewlines)
            try NetworkConfiguration.apply(value, to: URLSessionConfiguration.ephemeral)
            let networkChanged = preferences.effectiveJMDomains != value.effectiveJMDomains
                || preferences.effectiveImageDomain != value.effectiveImageDomain || preferences.effectivePicaDomain != value.effectivePicaDomain
                || preferences.proxyHost != value.proxyHost || preferences.proxyPort != value.proxyPort
            guard persistenceHealthy else { throw JMError.message("本地记录无法读取，设置尚未保存。请先备份原始记录。") }
            // Commit to disk before reporting success or modifying the live settings.
            do {
                try snapshotWriter(AppSnapshot(preferences: value, libraries: libraries, jobs: jobs,
                                               lastAccount: value.remember ? account : ""))
            } catch { throw JMError.message("设置未保存：无法写入设备存储，请检查剩余空间后重试。") }
            preferences = value
            if !value.remember { for name in SecureStore.accounts() { SecureStore.remove(name) }; accounts = [] }
            alert = nil
            if networkChanged { log("线路设置已保存；请重新登录。后台图片代理将在下次启动时更新。") }
            return true
        } catch { report(error); return false }
    }
}
