import SwiftUI
import UniformTypeIdentifiers

struct SettingsView: View {
    @Bindable var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Label {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("JM downloader").font(.headline)
                            Text(store.connected ? store.account : "尚未登录").font(.caption).foregroundStyle(.secondary)
                        }
                    } icon: { Image(systemName: "arrow.down.app.fill").font(.largeTitle).foregroundStyle(.orange) }
                        .padding(.vertical, 8)
                }
                Section {
                    NavigationLink { AccountSettingsView(store: store) } label: { Label("账号设置", systemImage: "person.crop.circle") }
                        .accessibilityIdentifier("accountSettings")
                    NavigationLink { ComicSettingsView(store: store) } label: { Label("漫画设置", systemImage: "books.vertical") }
                }
                Section("关于") {
                    LabeledContent("版本", value: "1.0.0")
                    LabeledContent("系统", value: "iOS 26 · 原生 SwiftUI")
                    Text("后台图片传输由系统调度。强制退出后，重新打开可恢复任务；推荐与 PDF 合成会在系统允许执行时继续。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }.navigationTitle("设置").toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        }
    }
}

struct AccountSettingsView: View {
    @Bindable var store: AppStore
    @State private var username = ""
    @State private var password = ""
    @State private var draft = Preferences()
    @State private var directoryPicker = false
    @State private var initialized = false
    var body: some View {
        Form {
            Section("登录与切换账号") {
                if store.connected { Label("当前账号：\(store.account)", systemImage: "checkmark.seal.fill").foregroundStyle(.green) }
                TextField("账号", text: $username).textContentType(.username).textInputAutocapitalization(.never).autocorrectionDisabled()
                SecureField("密码", text: $password).textContentType(.password)
                Toggle("记住账号", isOn: $draft.remember)
                Button {
                    store.savePreferences(draft)
                    guard store.alert == nil else { return }
                    Task { await store.login(username: username, password: password); password = "" }
                } label: { HStack { Text(store.signingIn ? "正在登录…" : "登录 / 切换账号"); Spacer(); if store.signingIn { ProgressView() } } }
                    .disabled(store.signingIn || username.isEmpty || password.isEmpty)
                if !store.accounts.isEmpty {
                    Menu("切换已记住的账号") {
                        ForEach(store.accounts, id: \.self) { name in Button(name) { Task { await store.switchAccount(name) } } }
                    }.disabled(store.signingIn)
                }
                if store.connected { Button("退出当前账号", role: .destructive) { store.logout() } }
            }
            Section {
                TextField("API 域名（逗号分隔）", text: $draft.domains, axis: .vertical).lineLimit(2...4)
                    .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                TextField("图片域名", text: $draft.imageDomain).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                TextField("HTTP 代理主机（留空使用系统网络）", text: $draft.proxyHost).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                HStack { Text("代理端口"); Spacer(); TextField("端口", value: $draft.proxyPort, format: .number.grouping(.never)).keyboardType(.numberPad).multilineTextAlignment(.trailing) }
                Button("保存线路设置") { store.savePreferences(draft) }
            } header: { Text("API 与代理") } footer: {
                Text("支持无需认证的 HTTP CONNECT 代理。线路修改后重新登录；后台传输代理在下次启动应用时生效。")
            }
            Section("下载与收藏") {
                Stepper("图片并发：\(draft.concurrency)", value: $draft.concurrency, in: 1...12)
                Button { store.refreshFavorites() } label: {
                    HStack { Label("刷新收藏", systemImage: "arrow.clockwise"); Spacer(); if store.refreshing { ProgressView() } }
                }.disabled(store.refreshing || !store.connected)
                Toggle("刷新收藏后自动下载", isOn: $draft.autoDownload)
                Button { directoryPicker = true } label: {
                    LabeledContent("选择下载目录", value: draft.directoryName).font(.subheadline)
                }
                if draft.directoryBookmark != nil {
                    Button("恢复默认文件 App 目录") { draft.directoryBookmark = nil; draft.directoryName = "我的 iPhone / JM downloader" }
                }
                Toggle("隐藏已完成任务", isOn: $draft.hideCompleted)
                Toggle("隐藏已删除任务", isOn: $draft.hideDeleted)
            }
            Section {
                Text("密码仅存于此设备的系统钥匙串。关闭“记住账号”会移除此应用保存的所有账号密码。删除下载任务会保留已导出的 PDF。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }.navigationTitle("账号设置").navigationBarTitleDisplayMode(.inline)
            .onAppear { if !initialized { draft = store.preferences; username = store.account; initialized = true } }
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("保存") { store.savePreferences(draft) } } }
            .onChange(of: draft) { old, value in
                guard initialized else { return }
                // Persist toggles immediately; text fields are validated only when Save is tapped.
                if old.concurrency != value.concurrency || old.remember != value.remember
                    || old.autoDownload != value.autoDownload || old.hideCompleted != value.hideCompleted
                    || old.hideDeleted != value.hideDeleted || old.directoryBookmark != value.directoryBookmark {
                    var updated = store.preferences
                    updated.concurrency = value.concurrency; updated.remember = value.remember
                    updated.autoDownload = value.autoDownload; updated.hideCompleted = value.hideCompleted
                    updated.hideDeleted = value.hideDeleted; updated.directoryBookmark = value.directoryBookmark
                    updated.directoryName = value.directoryName
                    store.savePreferences(updated)
                }
            }
            .fileImporter(isPresented: $directoryPicker, allowedContentTypes: [.folder]) { result in
                do {
                    let url = try result.get()
                    guard url.startAccessingSecurityScopedResource() else { throw JMError.message("未能取得目录授权。") }
                    defer { url.stopAccessingSecurityScopedResource() }
                    draft.directoryBookmark = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
                    draft.directoryName = url.lastPathComponent
                } catch { store.report(error) }
            }
    }
}

struct ComicSettingsView: View {
    @Bindable var store: AppStore
    var body: some View {
        List {
            Section {
                ForEach(store.excluded) { comic in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(comic.title).font(.subheadline.weight(.medium))
                        HStack {
                            Text("JM \(comic.id)").font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            Button("恢复自动下载") { store.restoreAutomatic(comic) }.font(.caption)
                        }
                    }.padding(.vertical, 4)
                }
            } header: { Text("不再自动下载 · \(store.excluded.count)") } footer: {
                Text("名单按账号保存。这些漫画不会因刷新收藏自动进入队列，仍可手动下载。恢复后从下次刷新收藏生效。")
            }
        }.overlay { if store.excluded.isEmpty { ContentUnavailableView("暂无排除漫画", systemImage: "hand.raised", description: Text("长按漫画或在“更多”中批量添加")) } }
            .navigationTitle("漫画设置").navigationBarTitleDisplayMode(.inline)
    }
}
