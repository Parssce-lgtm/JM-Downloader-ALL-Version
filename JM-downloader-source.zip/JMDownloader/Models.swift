import Foundation

struct Comic: Codable, Identifiable, Hashable, Sendable {
    var id: String
    var title: String
    var folders: [String] = []
    var tags: [String] = []
    var reason: String = ""
}

enum JobState: String, Codable, Sendable {
    case queued, preparing, downloading, exporting, paused, completed, failed, deleted
    var label: String {
        switch self {
        case .queued: "等待下载"
        case .preparing: "读取章节"
        case .downloading: "下载中"
        case .exporting: "生成 PDF"
        case .paused: "已暂停"
        case .completed: "已完成"
        case .failed: "需要重试"
        case .deleted: "已删除"
        }
    }
}

struct PageAsset: Codable, Sendable {
    var url: URL
    var chapterID: String
    var filename: String
    var scrambleID: Int
}

struct DownloadJob: Codable, Identifiable, Sendable {
    var id = UUID()
    var owner: String
    var comic: Comic
    var state: JobState = .queued
    var pages: [PageAsset] = []
    var finished: Set<Int> = []
    var message = ""
    var output: URL?
    var created = Date()
    var progress: Double { pages.isEmpty ? 0 : Double(finished.count) / Double(pages.count) }
}

struct Preferences: Codable, Equatable, Sendable {
    var domains = "www.cdnhjk.net,www.cdngwc.cc,www.cdngwc.net,www.cdngwc.club"
    var imageDomain = "cdn-msp.jmapiproxy1.cc"
    var proxyHost = ""
    var proxyPort = 7890
    var concurrency = 6
    var remember = true
    var autoDownload = false
    var hideCompleted = false
    var hideDeleted = true
    var directoryBookmark: Data?
    var directoryName = "我的 iPhone / JM downloader"
}

struct Library: Codable, Sendable {
    var favorites: [Comic] = []
    var excluded: [Comic] = []
}

struct AppSnapshot: Codable {
    var preferences = Preferences()
    var libraries: [String: Library] = [:]
    var jobs: [DownloadJob] = []
    var lastAccount: String = ""
}

struct LogEntry: Identifiable {
    let id = UUID()
    let date = Date()
    var text: String
}

enum JMError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

enum Validation {
    static func numericID(_ value: String) throws -> String {
        guard !value.isEmpty, value.allSatisfy({ $0.isASCII && $0.isNumber }) else {
            throw JMError.message("接口返回了无效漫画 ID。")
        }
        return value
    }
    static func hosts(_ value: String) throws -> [String] {
        let values = value.replacingOccurrences(of: "，", with: ",").split { $0 == "," || $0.isWhitespace }
        let result = try values.map { value -> String in
            let raw = String(value)
            guard let url = URLComponents(string: raw.contains("://") ? raw : "https://" + raw),
                  url.scheme == "https", let host = url.host, !host.isEmpty,
                  url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
                  url.path.isEmpty || url.path == "/", url.port == nil else {
                throw JMError.message("API / 图片域名须为 HTTPS 主机，不含路径、端口或账号。")
            }
            return host
        }
        guard !result.isEmpty else { throw JMError.message("请至少填写一个 API 域名。") }
        return result
    }
    static func safeName(_ title: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\:*?\"<>|\n\r").union(.controlCharacters)
        let name = String(title.components(separatedBy: invalid).joined(separator: "_").prefix(65))
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty || name == "." || name == ".." ? "漫画" : name
    }
}
