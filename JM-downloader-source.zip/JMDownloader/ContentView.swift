import SwiftUI
import UIKit

enum SelectionMode { case none, download, hide }
enum LibraryTab: String, CaseIterable { case downloads = "下载任务", favorites = "漫画收藏", recommendations = "漫画推荐" }

struct ContentView: View {
    @Bindable var store: AppStore
    @State private var settings = false
    @State private var showLogs = false
    @State private var tab: LibraryTab = .favorites
    @State private var folder = "全部收藏夹"
    @State private var query = ""
    @State private var showSearch = false
    @State private var globalSearch = false
    @State private var showDownloadedFavorites = false
    @State private var showHiddenFavorites = false
    @State private var showDownloadedRecommendations = false
    @State private var searchPage = 1
    @State private var mode: SelectionMode = .none
    @State private var selected = Set<String>()
    @State private var deleteAnchor: String?
    @State private var deleteIDs = Set<String>()
    @State private var previewComic: Comic?
    @FocusState private var searchFocused: Bool

    private var source: [Comic] { globalSearch ? store.searchResults : (tab == .favorites ? store.favorites : store.recommendations) }
    private var comics: [Comic] {
        source.filter { (globalSearch || tab != .recommendations || !store.isBlocked($0)) && (globalSearch || tab != .favorites || showHiddenFavorites || !store.isHiddenFavorite($0)) && (globalSearch || (tab == .favorites ? showDownloadedFavorites : showDownloadedRecommendations) || !store.isDownloaded($0)) && (folder == "全部收藏夹" || $0.folders.contains(folder) || tab == .recommendations || globalSearch)
            && (query.isEmpty || globalSearch || $0.title.localizedCaseInsensitiveContains(query) || $0.id.contains(query)) }
    }
    private var selectionItems: [Comic] { tab == .downloads ? tasks.map(\.comic) : comics }
    private var catalog: [Comic] {
        var seen = Set<String>()
        return (source + store.visibleJobs.map(\.comic)).filter { seen.insert($0.id).inserted }
    }
    private var tasks: [DownloadJob] {
        store.visibleJobs.filter { query.isEmpty || globalSearch || $0.comic.title.localizedCaseInsensitiveContains(query) || $0.comic.id.contains(query) }
    }
    private var busy: Bool { globalSearch ? store.searching : (tab == .favorites ? store.refreshing : store.recommending) }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Picker("浏览类型", selection: $tab) {
                    ForEach(LibraryTab.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                }.pickerStyle(.segmented).accessibilityIdentifier("libraryTabs").padding(.horizontal, 16)
                    .onChange(of: tab) { _, value in
                        globalSearch = false; showSearch = false; searchFocused = false; query = ""; endSelection()
                        if value == .recommendations && store.recommendations.isEmpty && !store.recommending { store.loadRecommendations() }
                    }
                VStack(spacing: 10) {
                    if tab == .downloads { queueControls.padding(.horizontal, 16) }
                    else { toolsPane.padding(.horizontal, 16) }
                    if tab == .downloads { queuePane }
                    else { libraryPane }
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                    .simultaneousGesture(DragGesture(minimumDistance: 28).onEnded { value in
                        let dx = value.translation.width, dy = value.translation.height
                        guard abs(dx) > 65, abs(dx) > abs(dy) * 1.5,
                              let index = LibraryTab.allCases.firstIndex(of: tab) else { return }
                        let next = index + (dx < 0 ? 1 : -1)
                        guard LibraryTab.allCases.indices.contains(next) else { return }
                        withAnimation(.snappy) { tab = LibraryTab.allCases[next] }
                    })
            }.background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("JM downloader")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("设置", systemImage: "gearshape") { settings = true }
                        .labelStyle(.iconOnly).accessibilityIdentifier("settings")
                }
            }
            .sheet(isPresented: $settings) { SettingsView(store: store) }
            .sheet(isPresented: $showLogs) { logsSheet }
            .sheet(item: $previewComic) { CoverPreview(comic: $0, preferences: store.preferences) }
            .alert("提示", isPresented: Binding(get: { store.alert != nil && !settings }, set: { if !$0 && !settings { store.alert = nil } })) {
                Button("好") { store.alert = nil }
            } message: { Text(store.alert ?? "") }
            .onChange(of: store.platform) { _, _ in endSelection(); folder = "全部收藏夹"; globalSearch = false; query = "" }
            .onChange(of: store.account) { _, _ in endSelection(); folder = "全部收藏夹"; globalSearch = false; query = "" }
        }.scrollDismissesKeyboard(.interactively).background(KeyboardDismissInstaller())
    }
    private var toolsPane: some View {
        VStack(spacing: 8) {
            controls
            if showSearch {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("搜索 JM 号、漫画名或标签", text: $query).submitLabel(.search)
                        .focused($searchFocused).accessibilityIdentifier("comicSearchField")
                        .task { searchFocused = true }
                        .onSubmit { submitSearch() }
                    if !query.isEmpty {
                        Button { query = ""; globalSearch = false } label: { Image(systemName: "xmark.circle.fill") }
                            .accessibilityLabel("清除搜索")
                    }
                    Button("搜索") { submitSearch() }.disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        .accessibilityIdentifier("submitComicSearch")
                }.font(.subheadline).padding(10).background(.background, in: RoundedRectangle(cornerRadius: 12))
            }
            if mode != .none { selectionBar }
        }
    }
    private var libraryPane: some View {
        VStack(spacing: 0) {
            ScrollView {
                LazyVStack(spacing: 9) {
                    if comics.isEmpty {
                        emptyLibrary
                    } else {
                        ForEach(comics) { comic in comicRow(comic) }
                        if globalSearch {
                            Button("加载更多") { searchPage += 1; store.search(query, page: searchPage) }.disabled(store.searching)
                        }
                    }
                }.padding(.bottom, 8)
            }
            .refreshable {
                if tab == .downloads { store.scanDownloadDirectory() } else if tab == .favorites { store.refreshFavorites() } else { store.loadRecommendations() }
            }
        }.padding(.horizontal, 16).padding(.top, 8)
    }
    private var controls: some View {
        HStack(spacing: 18) {
            if tab == .recommendations {
                Menu {
                    Picker("排序", selection: Binding(get: { store.recommendationSort }, set: { store.setRecommendationSort($0) })) {
                        ForEach(RecommendationSort.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                } label: { Label("排序 · " + store.recommendationSort.rawValue, systemImage: "arrow.up.arrow.down") }
                .accessibilityIdentifier("recommendationSort")
                searchButton
            } else {
                searchButton
                Menu {
                    Button("全部收藏夹") { folder = "全部收藏夹" }
                    ForEach(Array(Set(store.favorites.flatMap(\.folders))).sorted(), id: \.self) { item in
                        Button(item) { folder = item; globalSearch = false }
                    }
                } label: { Label(folder == "全部收藏夹" ? "收藏夹" : folder, systemImage: "folder").lineLimit(1) }
            }
            Spacer(minLength: 0)
            Menu {
                Button("选择漫画", systemImage: "checkmark.circle") { beginSelection(.download) }
                if tab == .favorites {
                    Button("选择隐藏漫画", systemImage: "eye.slash") { beginSelection(.hide) }
                    Divider()
                    Button("刷新当前列表", systemImage: "arrow.clockwise") { store.refreshFavorites() }
                    Button(showDownloadedFavorites ? "隐藏已下载" : "查看已下载", systemImage: "checkmark.circle") {
                        showDownloadedFavorites.toggle(); endSelection()
                    }
                    Button(showHiddenFavorites ? "收起隐藏漫画" : "查看隐藏漫画", systemImage: "eye") {
                        showHiddenFavorites.toggle(); endSelection()
                    }
                } else {
                    Button("刷新列表", systemImage: "arrow.clockwise") { store.loadRecommendations() }
                    Divider()
                    Button(showDownloadedRecommendations ? "隐藏已下载" : "查看已下载", systemImage: "checkmark.circle") {
                        showDownloadedRecommendations.toggle(); endSelection()
                    }
                }
            } label: { Label("更多", systemImage: "ellipsis.circle") }
                .popover(isPresented: deletionBinding("more"), attachmentAnchor: .rect(.bounds)) { deletionContent }

        }.font(.subheadline.weight(.medium)).foregroundStyle(.primary)
            .frame(minHeight: 36)
    }
    private var selectionBar: some View {
        HStack {
            Button(selected.count == selectionItems.count && !selectionItems.isEmpty ? "取消全选" : "全选") {
                if selected == Set(selectionItems.map(\.id)) { selected = [] } else { selected = Set(selectionItems.map(\.id)) }
            }
            Text("已选 \(selected.count)").foregroundStyle(.secondary)
            Spacer()
            Button(mode == .hide ? "隐藏漫画" : "下载") {
                let items = catalog.filter { selected.contains($0.id) }
                if mode == .hide { store.hideFavorites(items) } else { store.enqueue(items) }
                endSelection()
            }.disabled(selected.isEmpty)
            Button("取消") { endSelection() }
        }.font(.caption.weight(.medium))
    }
    private var emptyLibrary: some View {
        VStack(spacing: 8) {
            Image(systemName: busy ? "books.vertical" : "books.vertical.fill").font(.system(size: 30)).foregroundStyle(store.preferences.accent.opacity(0.7))
            Text(busy ? "正在为你整理漫画…" : (store.connected ? "这里还没有漫画" : "书架等你开启")).font(.headline)
            Text(busy ? "你可以继续查看下载任务" : (store.connected ? "已下载漫画默认收起，可在更多中查看" : "在右上角登录，或搜索漫画标题与编号"))
                .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            if !store.connected { Button("前往账号设置") { settings = true }.buttonStyle(.bordered) }
        }.frame(maxWidth: .infinity).padding(.vertical, 20)
    }
    private func comicRow(_ comic: Comic) -> some View {
        HStack(spacing: 12) {
            if mode != .none { checkmark(comic.id) }
            CoverView(comic: comic, preferences: store.preferences).frame(width: 46, height: 62).clipShape(RoundedRectangle(cornerRadius: 8))
                .onTapGesture(count: 2) { previewComic = comic }
            VStack(alignment: .leading, spacing: 5) {
                Text(comic.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                Text(comic.reason.isEmpty ? comic.reference : comic.reason).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
            if mode == .none {
                if store.isDownloaded(comic) {
                    Image(systemName: "checkmark.circle.fill").font(.title2).foregroundStyle(.green)
                        .accessibilityLabel("已下载 \(comic.title)").accessibilityIdentifier("downloaded-" + comic.id)
                } else if store.jobs.contains(where: { $0.owner == store.account && $0.comic.source == comic.source && $0.comic.id == comic.id && $0.state.isRunning }) {
                    ProgressView().controlSize(.regular).frame(width: 28, height: 28)
                        .accessibilityLabel("正在下载 " + comic.title).accessibilityIdentifier("downloading-" + comic.id)
                } else {
                    Button { store.enqueue([comic]) } label: { Image(systemName: "arrow.down.circle.fill").font(.title2) }
                        .accessibilityLabel("下载 \(comic.title)").disabled(store.scanningDownloads)
                }
            }
        }.padding(10).modifier(ComicCardStyle())
            .contentShape(Rectangle()).onTapGesture { if mode != .none { toggle(comic.id) } }
            .contextMenu { comicMenu(comic, anchor: "library:" + DownloadCatalog.key(comic)) }
            .popover(isPresented: deletionBinding("library:" + DownloadCatalog.key(comic)), attachmentAnchor: .rect(.bounds)) { deletionContent }
    }
    private var queueControls: some View {
        VStack(spacing: 10) {
            HStack {
                Label("漫画下载状态", systemImage: "arrow.down.to.line.compact").font(.headline)
                Spacer()
                Text("\(tasks.count) 个任务").font(.caption).foregroundStyle(.secondary)
            }
            HStack {
                Button("全部开始", systemImage: "play.fill") { store.startAll() }.accessibilityIdentifier("startAll")
                Spacer()
                Button("全部暂停", systemImage: "pause.fill") { store.pauseAll() }.accessibilityIdentifier("pauseAll")
                Menu {
                    Button("选择任务") { beginSelection(.download) }
                    Button("删除任务及下载缓存", role: .destructive) {
                        if mode == .none { beginSelection(.download) }
                        else if !selected.isEmpty { deleteIDs = selected; deleteAnchor = "queue" }
                    }.disabled(mode != .none && selected.isEmpty)
                } label: { Image(systemName: "ellipsis.circle") }
                .accessibilityLabel("任务操作")
                .popover(isPresented: deletionBinding("queue"), attachmentAnchor: .rect(.bounds)) { deletionContent }
            }.font(.subheadline.weight(.medium))
            if mode != .none { selectionBar }
        }.padding(.vertical, 6)
    }
    private var queuePane: some View {
        VStack(spacing: 0) {
            ScrollView {
                LazyVStack(spacing: 10) {
                    if tasks.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "tray.and.arrow.down").font(.largeTitle).foregroundStyle(.tertiary)
                            Text("下载队列空空的").font(.subheadline.weight(.medium))
                            Text("选一本漫画开始，进度会显示在这里").font(.caption).foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity).padding(.vertical, 30)
                    }
                    ForEach(tasks) { job in jobRow(job) }
                }.padding(.horizontal, 16).padding(.bottom, 8)
            }
            Button { showLogs = true } label: {
                HStack(alignment: .center, spacing: 12) {
                    Image(systemName: "text.bubble").font(.title3)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("提示记录").font(.caption.weight(.semibold))
                        Text(store.logs.first?.text ?? "准备就绪 · 下载文件保存在文件 App")
                            .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption2)
                }.foregroundStyle(.primary).padding(.horizontal, 22).padding(.vertical, 14)
                    .frame(maxWidth: .infinity, minHeight: 66)
                    .background(.thinMaterial, in: Capsule())
                    .contentShape(Capsule())
            }.buttonStyle(.plain).accessibilityIdentifier("logCapsule")
                .padding(.horizontal, 16).padding(.bottom, 8).padding(.top, 6)
        }
    }
    private func jobRow(_ job: DownloadJob) -> some View {
        HStack(spacing: 10) {
            if mode != .none { checkmark(job.comic.id) }
            CoverView(comic: job.comic, preferences: store.preferences).frame(width: 48, height: 68).clipShape(RoundedRectangle(cornerRadius: 8))
                .onTapGesture(count: 2) { previewComic = job.comic }
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .top) {
                    Text(job.comic.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                    Spacer(minLength: 0)
                    if mode == .none { taskButton(job) }
                }
                ProgressView(value: job.progress).tint(job.state == .completed ? .green : store.preferences.accent)
                HStack {
                    Text(job.state.label).foregroundStyle(job.state == .failed ? .red : .secondary)
                    Spacer()
                    Text(job.pages.isEmpty ? job.comic.reference : "\(job.finished.count) / \(job.pages.count) 张")
                }.font(.caption2).monospacedDigit()
                if !job.message.isEmpty { Text(job.message).font(.caption2).foregroundStyle(.secondary).lineLimit(2) }
            }
        }.padding(12).modifier(ComicCardStyle())
            .contentShape(Rectangle()).onTapGesture { if mode != .none { toggle(job.comic.id) } }
            .contextMenu {
                if job.state.isRunning { Button("暂停下载", systemImage: "pause") { store.engine.pause(job.id) } }
                comicMenu(job.comic, anchor: "job:" + job.id.uuidString)
                if let output = job.output { ShareLink(item: output) { Label("分享 PDF", systemImage: "square.and.arrow.up") } }
            }
            .popover(isPresented: deletionBinding("job:" + job.id.uuidString), attachmentAnchor: .rect(.bounds)) { deletionContent }
    }
    @ViewBuilder private func taskButton(_ job: DownloadJob) -> some View {
        if job.state == .completed {
            if let output = job.output { ShareLink(item: output) { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("分享 PDF") }
        } else if [.paused, .failed, .deleted].contains(job.state) {
            Button { store.resumeJob(job.id) } label: { Image(systemName: "play.circle.fill").font(.title3) }.accessibilityLabel("继续下载")
        } else {
            Button { store.engine.pause(job.id) } label: { Image(systemName: "pause.circle").font(.title3) }.accessibilityLabel("暂停下载")
        }
    }
    @ViewBuilder private func comicMenu(_ comic: Comic, anchor: String) -> some View {
        if tab != .downloads && !store.isDownloaded(comic) { Button("下载漫画", systemImage: "arrow.down") { store.enqueue([comic]) } }
        if tab == .favorites {
            if store.isHiddenFavorite(comic) {
                Button("取消隐藏漫画", systemImage: "eye") { store.showFavorite(comic) }
            } else {
                Button("隐藏漫画", systemImage: "eye.slash") { store.hideFavorites([comic]) }
            }
        } else {
            if store.isAutomaticExcluded(comic) {
                Button("开启自动下载", systemImage: "arrow.triangle.2.circlepath") { store.restoreAutomatic(comic) }
            } else {
                Button("不再自动下载", systemImage: "hand.raised") { store.exclude([comic]) }
            }
            Button("删除任务及下载缓存", systemImage: "trash", role: .destructive) {
                deleteIDs = [comic.id]; deleteAnchor = anchor
            }
        }
    }
    private func deletionBinding(_ anchor: String) -> Binding<Bool> {
        Binding(get: { deleteAnchor == anchor }, set: { if !$0 && deleteAnchor == anchor { deleteAnchor = nil } })
    }
    private var deletionContent: some View {
        VStack(spacing: 16) {
            Text("删除任务及下载缓存？").font(.headline)
            Text("将删除 \(deleteIDs.count) 个任务及其下载缓存，已保存的 PDF 会保留。").font(.subheadline).foregroundStyle(.secondary)
            Button("删除任务及下载缓存", role: .destructive) {
                store.deleteJobs(comicIDs: deleteIDs); deleteAnchor = nil; endSelection()
            }.buttonStyle(.borderedProminent).tint(.red).accessibilityIdentifier("confirmDelete")
            Button("取消") { deleteAnchor = nil }
        }.padding(20).frame(width: 260).presentationCompactAdaptation(.popover)
    }
    private func checkmark(_ id: String) -> some View {
        Image(systemName: selected.contains(id) ? "checkmark.circle.fill" : "circle")
            .font(.title2).foregroundStyle(selected.contains(id) ? store.preferences.accent : Color.secondary)
            .frame(width: 28).transition(.move(edge: .leading).combined(with: .opacity))
            .accessibilityLabel(selected.contains(id) ? "已选择" : "未选择")
    }
    private func toggle(_ id: String) { if !selected.insert(id).inserted { selected.remove(id) } }
    private var searchButton: some View {
        Button("搜索", systemImage: "magnifyingglass") {
            showSearch = true; searchFocused = true; endSelection()
        }.accessibilityIdentifier("openComicSearch")
    }
    private func submitSearch() {
        let value = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        query = value; globalSearch = true; searchPage = 1; searchFocused = false
        store.search(value)
    }
    private func beginSelection(_ value: SelectionMode) { withAnimation(.snappy) { mode = value; selected = [] } }
    private func endSelection() { withAnimation(.snappy) { mode = .none; selected = [] } }
    private var logsSheet: some View {
        NavigationStack {
            List(store.logs) { entry in
                VStack(alignment: .leading, spacing: 5) {
                    Text(entry.text)
                    Text(entry.date, style: .time).font(.caption).foregroundStyle(.secondary)
                }
            }.overlay { if store.logs.isEmpty { ContentUnavailableView("暂无提示", systemImage: "text.bubble") } }
                .navigationTitle("提示记录").toolbar { Button("完成") { showLogs = false } }
        }.presentationDetents([.medium, .large])
    }
}

private struct ComicCardStyle: ViewModifier {
    @Environment(\.colorScheme) private var colorScheme
    func body(content: Content) -> some View {
        content.background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
            .overlay { RoundedRectangle(cornerRadius: 16)
                .strokeBorder(Color.primary.opacity(colorScheme == .dark ? 0.14 : 0.06), lineWidth: 0.7)
                .allowsHitTesting(false) }
    }
}

struct CoverPreview: View {
    let comic: Comic
    let preferences: Preferences
    @Environment(\.dismiss) private var dismiss
    @State private var image: UIImage?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 18).fill(preferences.accent.opacity(0.12))
                        if let image { Image(uiImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 18)) }
                        else { ProgressView().controlSize(.large) }
                    }.frame(maxWidth: .infinity).frame(height: 420)
                    Text(comic.title).font(.title2.bold())
                    Text(comic.reference).font(.subheadline).foregroundStyle(.secondary)
                    if !comic.tags.isEmpty { Text(comic.tags.joined(separator: " · ")).font(.footnote).foregroundStyle(.secondary) }
                    HStack { Label(comic.folders.joined(separator: "、"), systemImage: "folder"); Spacer(); Text(comic.reason).foregroundStyle(.secondary) }.font(.footnote)
                }.padding()
            }.navigationTitle("封面详情").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
        }.task {
            do { image = UIImage(data: try await CoverCache.shared.load(comic: comic, preferences: preferences)) } catch { }
        }.tint(preferences.accent).preferredColorScheme(preferences.colorScheme)
    }
}

struct CoverView: View {
    let comic: Comic
    let preferences: Preferences
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            LinearGradient(colors: [preferences.accent.opacity(0.2), preferences.accent.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing)
            if let image { Image(uiImage: image).resizable().scaledToFill() }
            else { Image(systemName: "book.closed.fill").foregroundStyle(preferences.accent.opacity(0.6)) }
        }.clipped().accessibilityHidden(true)
            .task(id: DownloadCatalog.key(comic)) {
                #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--ui-fixture-v120") {
                    image = UIGraphicsImageRenderer(size: CGSize(width: 90, height: 120)).image { context in
                        let color: UIColor = comic.id == "10001" ? .systemBlue : (comic.id == "10002" ? .systemOrange : .systemGreen)
                        color.setFill(); context.fill(CGRect(x: 0, y: 0, width: 90, height: 120))
                    }
                    return
                }
                #endif
                do {
                    let data = try await CoverCache.shared.load(comic: comic, preferences: preferences)
                    try Task.checkCancellation()
                    image = UIImage(data: data)
                } catch { /* Cover failure does not block the queue. */ }
            }
    }
}
