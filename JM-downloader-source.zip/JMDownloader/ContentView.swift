import SwiftUI

enum SelectionMode { case none, download, exclude }
enum LibraryTab: String, CaseIterable { case downloads = "下载任务", favorites = "漫画收藏", recommendations = "漫画推荐" }

struct ContentView: View {
    @Bindable var store: AppStore
    @State private var settings = false
    @State private var showLogs = false
    @State private var tab: LibraryTab = .favorites
    @State private var folder = "全部收藏夹"
    @State private var query = ""
    @State private var showSearch = false
    @State private var globalSearch = false
    @State private var searchPage = 1
    @State private var mode: SelectionMode = .none
    @State private var selected = Set<String>()
    @State private var deleteAnchor: String?
    @State private var deleteIDs = Set<String>()

    private var source: [Comic] { globalSearch ? store.searchResults : (tab == .favorites ? store.favorites : store.recommendations) }
    private var comics: [Comic] {
        source.filter { (folder == "全部收藏夹" || $0.folders.contains(folder) || tab == .recommendations || globalSearch)
            && (query.isEmpty || globalSearch || $0.title.localizedCaseInsensitiveContains(query) || $0.id.contains(query)) }
    }
    private var selectionItems: [Comic] { tab == .downloads ? tasks.map(\.comic) : comics }
    private var catalog: [Comic] {
        var seen = Set<String>()
        return (source + store.visibleJobs.map(\.comic)).filter { seen.insert($0.id).inserted }
    }
    private var tasks: [DownloadJob] {
        store.visibleJobs.filter { query.isEmpty || globalSearch || $0.comic.title.localizedCaseInsensitiveContains(query) || $0.comic.id.contains(query) }
    }
    private var busy: Bool { globalSearch ? store.searching : (tab == .favorites ? store.refreshing : store.recommending) }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("\(store.platform.label) 书架").font(.title3.bold())
                        Text(!store.account.isEmpty ? "\(store.favorites.count) 部收藏 · 随时离线阅读" : "登录账号，同步你的收藏")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if busy || store.scanningDownloads { ProgressView().controlSize(.small).accessibilityLabel("正在后台加载") }
                }.padding(.horizontal, 16).padding(.top, 8)
                Picker("浏览类型", selection: $tab) {
                    ForEach(LibraryTab.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                }.pickerStyle(.segmented).accessibilityIdentifier("libraryTabs").padding(.horizontal, 16)
                    .onChange(of: tab) { _, value in
                        globalSearch = false; endSelection()
                        if value == .recommendations && store.recommendations.isEmpty { store.loadRecommendations() }
                    }
                toolsPane.padding(.horizontal, 16)
                if tab == .downloads { queuePane }
                else { libraryPane }
            }.background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("JM downloader")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Image(systemName: "arrow.down.app.fill").foregroundStyle(store.preferences.accent).font(.title2)
                        .accessibilityHidden(true)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("设置", systemImage: "gearshape") { settings = true }
                        .labelStyle(.iconOnly).accessibilityIdentifier("settings")
                }
            }
            .sheet(isPresented: $settings) { SettingsView(store: store) }
            .sheet(isPresented: $showLogs) { logsSheet }
            .alert("提示", isPresented: Binding(get: { store.alert != nil && !settings }, set: { if !$0 && !settings { store.alert = nil } })) {
                Button("好") { store.alert = nil }
            } message: { Text(store.alert ?? "") }
            .onChange(of: store.platform) { _, _ in endSelection(); folder = "全部收藏夹"; globalSearch = false; query = "" }
            .onChange(of: store.account) { _, _ in endSelection(); folder = "全部收藏夹"; globalSearch = false; query = "" }
        }.scrollDismissesKeyboard(.interactively).background(KeyboardDismissInstaller())
    }
    private var toolsPane: some View {
        VStack(spacing: 8) {
            controls
            if showSearch {
                HStack {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("搜索标题或漫画编号", text: $query).submitLabel(.search)
                        .onSubmit { if tab != .downloads { globalSearch = true; searchPage = 1; store.search(query) } }
                    if !query.isEmpty {
                        Button { query = ""; globalSearch = false } label: { Image(systemName: "xmark.circle.fill") }
                            .accessibilityLabel("清除搜索")
                    }
                    if tab != .downloads { Button("全站") { globalSearch = true; searchPage = 1; store.search(query) }.disabled(query.isEmpty) }
                }.font(.subheadline).padding(10).background(.background, in: RoundedRectangle(cornerRadius: 12))
            }
            if mode != .none { selectionBar }
        }
    }
    private var libraryPane: some View {
        VStack(spacing: 0) {
            ScrollView {
                LazyVStack(spacing: 9) {
                    if comics.isEmpty {
                        emptyLibrary
                    } else {
                        ForEach(comics) { comic in comicRow(comic) }
                        if globalSearch {
                            Button("加载更多") { searchPage += 1; store.search(query, page: searchPage) }.disabled(store.searching)
                        }
                    }
                }.padding(.bottom, 8)
            }
            .refreshable {
                if tab == .downloads { store.scanDownloadDirectory() } else if tab == .favorites { store.refreshFavorites() } else { store.loadRecommendations() }
            }
        }.padding(.horizontal, 16).padding(.top, 8)
    }
    private var controls: some View {
        HStack(spacing: 18) {
            Button("搜索", systemImage: "magnifyingglass") { withAnimation { showSearch.toggle() } }
            Menu {
                Button("全部收藏夹") { folder = "全部收藏夹" }
                ForEach(Array(Set(store.favorites.flatMap(\.folders))).sorted(), id: \.self) { item in
                    Button(item) { folder = item; tab = .favorites; globalSearch = false }
                }
            } label: { Label(folder == "全部收藏夹" ? "收藏夹" : folder, systemImage: "folder").lineLimit(1) }
            Spacer(minLength: 0)
            Menu {
                Button("选择漫画", systemImage: "checkmark.circle") { beginSelection(.download) }
                Button("选择不再自动下载", systemImage: "hand.raised") { beginSelection(.exclude) }
                Button("删除所选任务", systemImage: "trash", role: .destructive) {
                    if mode == .none { beginSelection(.download) } else { if !selected.isEmpty { deleteIDs = selected; deleteAnchor = "more" } }
                }
                Divider()
                Button("刷新当前列表", systemImage: "arrow.clockwise") {
                    if tab == .downloads { store.scanDownloadDirectory() } else if tab == .favorites { store.refreshFavorites() } else { store.loadRecommendations() }
                }
            } label: { Label("更多", systemImage: "ellipsis.circle") }
                .popover(isPresented: deletionBinding("more"), attachmentAnchor: .rect(.bounds)) { deletionContent }

        }.font(.subheadline.weight(.medium)).foregroundStyle(.primary)
            .frame(minHeight: 36)
    }
    private var selectionBar: some View {
        HStack {
            Button(selected.count == selectionItems.count && !selectionItems.isEmpty ? "取消全选" : "全选") {
                if selected == Set(selectionItems.map(\.id)) { selected = [] } else { selected = Set(selectionItems.map(\.id)) }
            }
            Text("已选 \(selected.count)").foregroundStyle(.secondary)
            Spacer()
            Button(mode == .exclude ? "不再自动下载" : "下载") {
                let items = catalog.filter { selected.contains($0.id) }
                if mode == .exclude { store.exclude(items) } else { store.enqueue(items) }
                endSelection()
            }.disabled(selected.isEmpty)
            Button("取消") { endSelection() }
        }.font(.caption.weight(.medium))
    }
    private var emptyLibrary: some View {
        VStack(spacing: 8) {
            Image(systemName: busy ? "books.vertical" : "books.vertical.fill").font(.system(size: 30)).foregroundStyle(store.preferences.accent.opacity(0.7))
            Text(busy ? "正在为你整理漫画…" : (store.connected ? "这里还没有漫画" : "书架等你开启")).font(.headline)
            Text(busy ? "你可以继续查看下载任务" : "在右上角登录，或搜索漫画标题与编号")
                .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            if !store.connected { Button("前往账号设置") { settings = true }.buttonStyle(.bordered) }
        }.frame(maxWidth: .infinity).padding(.vertical, 20)
    }
    private func comicRow(_ comic: Comic) -> some View {
        HStack(spacing: 12) {
            if mode != .none { checkmark(comic.id) }
            CoverView(comic: comic, preferences: store.preferences).frame(width: 46, height: 62).clipShape(RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading, spacing: 5) {
                Text(comic.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                Text(comic.reason.isEmpty ? comic.reference : comic.reason).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 0)
            if mode == .none {
                if store.isDownloaded(comic) {
                    Image(systemName: "checkmark.circle.fill").font(.title2).foregroundStyle(.green)
                        .accessibilityLabel("已下载 \(comic.title)").accessibilityIdentifier("downloaded-" + comic.id)
                } else {
                    Button { store.enqueue([comic]) } label: { Image(systemName: "arrow.down.circle.fill").font(.title2) }
                        .accessibilityLabel("下载 \(comic.title)").disabled(store.scanningDownloads)
                }
            }
        }.padding(10).background(.background, in: RoundedRectangle(cornerRadius: 16))
            .contentShape(Rectangle()).onTapGesture { if mode != .none { toggle(comic.id) } }
            .contextMenu { comicMenu(comic, anchor: "library:" + DownloadCatalog.key(comic)) }
            .popover(isPresented: deletionBinding("library:" + DownloadCatalog.key(comic)), attachmentAnchor: .rect(.bounds)) { deletionContent }
    }
    private var queuePane: some View {
        VStack(spacing: 0) {
            HStack {
                Label("漫画下载状态", systemImage: "arrow.down.to.line.compact").font(.headline)
                Spacer()
                Text("\(tasks.count) 个任务").font(.caption).foregroundStyle(.secondary)
            }.padding(.horizontal, 18).padding(.vertical, 14)
            HStack {
                Button("全部开始", systemImage: "play.fill") { store.startAll() }.accessibilityIdentifier("startAll")
                Spacer()
                Button("全部暂停", systemImage: "pause.fill") { store.pauseAll() }.accessibilityIdentifier("pauseAll")
            }.font(.subheadline.weight(.medium)).padding(.horizontal, 18).padding(.bottom, 12)
            ScrollView {
                LazyVStack(spacing: 10) {
                    if tasks.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "tray.and.arrow.down").font(.largeTitle).foregroundStyle(.tertiary)
                            Text("下载队列空空的").font(.subheadline.weight(.medium))
                            Text("选一本漫画开始，进度会显示在这里").font(.caption).foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity).padding(.vertical, 30)
                    }
                    ForEach(tasks) { job in jobRow(job) }
                }.padding(.horizontal, 16).padding(.bottom, 8)
            }
            Button { showLogs = true } label: {
                HStack(alignment: .top, spacing: 9) {
                    Image(systemName: "text.bubble").padding(.top, 2)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("提示记录").font(.caption.weight(.semibold))
                        Text(store.logs.first?.text ?? "准备就绪 · 下载文件保存在文件 App")
                            .font(.caption2).foregroundStyle(.secondary).lineLimit(2)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption2)
                }.foregroundStyle(.primary).padding(12)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
            }.padding(.horizontal, 16).padding(.bottom, 8).padding(.top, 6)
        }
    }
    private func jobRow(_ job: DownloadJob) -> some View {
        HStack(spacing: 10) {
            if mode != .none { checkmark(job.comic.id) }
            CoverView(comic: job.comic, preferences: store.preferences).frame(width: 48, height: 68).clipShape(RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .top) {
                    Text(job.comic.title).font(.subheadline.weight(.semibold)).lineLimit(2)
                    Spacer(minLength: 0)
                    if mode == .none { taskButton(job) }
                }
                ProgressView(value: job.progress).tint(job.state == .completed ? .green : store.preferences.accent)
                HStack {
                    Text(job.state.label).foregroundStyle(job.state == .failed ? .red : .secondary)
                    Spacer()
                    Text(job.pages.isEmpty ? job.comic.reference : "\(job.finished.count) / \(job.pages.count) 张")
                }.font(.caption2).monospacedDigit()
                if !job.message.isEmpty { Text(job.message).font(.caption2).foregroundStyle(.secondary).lineLimit(2) }
            }
        }.padding(12).background(.background, in: RoundedRectangle(cornerRadius: 16))
            .contentShape(Rectangle()).onTapGesture { if mode != .none { toggle(job.comic.id) } }
            .contextMenu {
                if [.paused, .failed, .deleted].contains(job.state) { Button("继续下载", systemImage: "play") { store.resumeJob(job.id) } }
                else if job.state != .completed { Button("暂停下载", systemImage: "pause") { store.engine.pause(job.id) } }
                comicMenu(job.comic, anchor: "job:" + job.id.uuidString)
                if let output = job.output { ShareLink(item: output) { Label("分享 PDF", systemImage: "square.and.arrow.up") } }
            }
            .popover(isPresented: deletionBinding("job:" + job.id.uuidString), attachmentAnchor: .rect(.bounds)) { deletionContent }
    }
    @ViewBuilder private func taskButton(_ job: DownloadJob) -> some View {
        if job.state == .completed {
            if let output = job.output { ShareLink(item: output) { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("分享 PDF") }
        } else if [.paused, .failed, .deleted].contains(job.state) {
            Button { store.resumeJob(job.id) } label: { Image(systemName: "play.circle.fill").font(.title3) }.accessibilityLabel("继续下载")
        } else {
            Button { store.engine.pause(job.id) } label: { Image(systemName: "pause.circle").font(.title3) }.accessibilityLabel("暂停下载")
        }
    }
    @ViewBuilder private func comicMenu(_ comic: Comic, anchor: String) -> some View {
        if !store.isDownloaded(comic) { Button("下载漫画", systemImage: "arrow.down") { store.enqueue([comic]) } }
        Button("不再自动下载", systemImage: "hand.raised") { store.exclude([comic]) }
        Button("删除任务（保留 PDF）", systemImage: "trash", role: .destructive) {
            deleteIDs = [comic.id]; deleteAnchor = anchor
        }
    }
    private func deletionBinding(_ anchor: String) -> Binding<Bool> {
        Binding(get: { deleteAnchor == anchor }, set: { if !$0 && deleteAnchor == anchor { deleteAnchor = nil } })
    }
    private var deletionContent: some View {
        VStack(spacing: 16) {
            Text("删除 \(deleteIDs.count) 个任务？").font(.headline)
            Text("已保存的 PDF 会保留。").font(.subheadline).foregroundStyle(.secondary)
            Button("删除所选任务", role: .destructive) {
                store.deleteJobs(comicIDs: deleteIDs); deleteAnchor = nil; endSelection()
            }.buttonStyle(.borderedProminent).tint(.red).accessibilityIdentifier("confirmDelete")
            Button("取消") { deleteAnchor = nil }
        }.padding(20).frame(width: 260).presentationCompactAdaptation(.popover)
    }
    private func checkmark(_ id: String) -> some View {
        Image(systemName: selected.contains(id) ? "checkmark.circle.fill" : "circle")
            .font(.title2).foregroundStyle(selected.contains(id) ? store.preferences.accent : Color.secondary)
            .frame(width: 28).transition(.move(edge: .leading).combined(with: .opacity))
            .accessibilityLabel(selected.contains(id) ? "已选择" : "未选择")
    }
    private func toggle(_ id: String) { if !selected.insert(id).inserted { selected.remove(id) } }
    private func beginSelection(_ value: SelectionMode) { withAnimation(.snappy) { mode = value; selected = [] } }
    private func endSelection() { withAnimation(.snappy) { mode = .none; selected = [] } }
    private var logsSheet: some View {
        NavigationStack {
            List(store.logs) { entry in
                VStack(alignment: .leading, spacing: 5) {
                    Text(entry.text)
                    Text(entry.date, style: .time).font(.caption).foregroundStyle(.secondary)
                }
            }.overlay { if store.logs.isEmpty { ContentUnavailableView("暂无提示", systemImage: "text.bubble") } }
                .navigationTitle("提示记录").toolbar { Button("完成") { showLogs = false } }
        }.presentationDetents([.medium, .large])
    }
}

struct CoverView: View {
    let comic: Comic
    let preferences: Preferences
    @State private var image: UIImage?
    var body: some View {
        ZStack {
            LinearGradient(colors: [preferences.accent.opacity(0.2), preferences.accent.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing)
            if let image { Image(uiImage: image).resizable().scaledToFill() }
            else { Image(systemName: "book.closed.fill").foregroundStyle(preferences.accent.opacity(0.6)) }
        }.clipped().accessibilityHidden(true)
            .task(id: DownloadCatalog.key(comic)) {
                do {
                    let data = try await CoverCache.shared.load(comic: comic, preferences: preferences)
                    try Task.checkCancellation()
                    image = UIImage(data: data)
                } catch { /* Cover failure does not block the queue. */ }
            }
    }
}
