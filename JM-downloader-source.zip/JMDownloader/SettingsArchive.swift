import Foundation

struct SettingsArchive: Codable, Sendable {
    struct ComicSettings: Codable, Sendable {
        var excluded: [Comic]
        var hidden: Set<String>
    }
    var version = 1
    var preferences: Preferences
    var accounts: [String: ComicSettings]
    init(_ snapshot: AppSnapshot) {
        preferences = snapshot.preferences
        preferences.directoryBookmark = nil; preferences.storageRootBookmark = nil
        preferences.directoryName = "downloads"
        accounts = snapshot.libraries.mapValues { ComicSettings(excluded: $0.excluded, hidden: $0.hiddenComicKeys ?? []) }
    }
    func apply(to snapshot: inout AppSnapshot) {
        let root = snapshot.preferences.storageRootBookmark, directory = snapshot.preferences.directoryBookmark
        let name = snapshot.preferences.directoryName
        snapshot.preferences = preferences
        snapshot.preferences.storageRootBookmark = root; snapshot.preferences.directoryBookmark = directory
        snapshot.preferences.directoryName = name
        for (account, settings) in accounts {
            snapshot.libraries[account, default: Library()].excluded = settings.excluded
            snapshot.libraries[account, default: Library()].hiddenComicKeys = settings.hidden
        }
    }
    static func read(from root: URL) throws -> SettingsArchive? {
        let file = root.appendingPathComponent("setting/settings.json")
        guard FileManager.default.fileExists(atPath: file.path) else { return nil }
        let value = try JSONDecoder().decode(Self.self, from: Data(contentsOf: file))
        guard value.version == 1 else { throw JMError.message("设置备份来自更新版本，请先更新软件；原文件已保留。") }
        return value
    }
    static func write(_ data: Data, to root: URL) throws {
        let folder = root.appendingPathComponent("setting", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let file = folder.appendingPathComponent("settings.json")
        if (try? Data(contentsOf: file)) != data { try data.write(to: file, options: .atomic) }
    }
}

/// External provider I/O must never block touches or PDF progress persistence.
final class SettingsBackupWriter: @unchecked Sendable {
    static let shared = SettingsBackupWriter()
    private let queue = DispatchQueue(label: "app.jmdownloader.settings-backup", qos: .utility)
    private let lock = NSLock()
    private var pending: AppSnapshot?
    private var draining = false
    private var lastData: Data?
    private var lastRoot: Data?
    func schedule(_ snapshot: AppSnapshot) {
        lock.lock()
        pending = snapshot
        if draining { lock.unlock(); return }
        draining = true; lock.unlock()
        queue.async {
            while let snapshot = self.takePending() { self.write(snapshot) }
        }
    }
    private func takePending() -> AppSnapshot? {
        lock.lock(); defer { lock.unlock() }
        let snapshot = pending; pending = nil
        if snapshot == nil { draining = false }
        return snapshot
    }
    private func write(_ snapshot: AppSnapshot) {
            do {
                let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys, .prettyPrinted]
                let data = try encoder.encode(SettingsArchive(snapshot))
                let bookmark = snapshot.preferences.storageRootBookmark
                guard data != self.lastData || bookmark != self.lastRoot else { return }
                try SettingsArchive.write(data, to: DiskStore.documents)
                if let bookmark {
                    let root = try DownloadDirectory.resolve(bookmark)
                    let scoped = root.startAccessingSecurityScopedResource()
                    defer { if scoped { root.stopAccessingSecurityScopedResource() } }
                    guard scoped else { throw JMError.message("外部设置备份目录需要重新授权；软件内 setting 副本已保存。") }
                    try SettingsArchive.write(data, to: root)
                }
                self.lastData = data; self.lastRoot = bookmark
                Task { @MainActor in AppStore.shared.settingsBackupNotice = bookmark == nil ? "setting 本地副本已保存，尚未授权外部备份" : "setting 已同步到外部目录" }
            } catch {
                Task { @MainActor in AppStore.shared.settingsBackupNotice = "设置外部备份未完成：" + AppStore.friendly(error) }
            }
    }
}

enum FixedStorage {
    struct Setup: Sendable {
        let root: Data
        let downloads: Data
        let name: String
        let restored: SettingsArchive?
    }
    static func prepare(_ selection: DownloadDirectory.Selection, allowAppDirectory: Bool = false) throws -> Setup {
        let root = try DownloadDirectory.resolve(selection.bookmark)
        let scoped = root.startAccessingSecurityScopedResource()
        defer { if scoped { root.stopAccessingSecurityScopedResource() } }
        guard allowAppDirectory || (!DownloadDirectory.isAppDirectory(root) && scoped) else {
            throw JMError.message("请选择 JM downloader 软件目录之外的文件夹，才能在卸载后保留 PDF 和设置。")
        }
        // Read first. Never replace an existing backup before restoring it.
        let restored = try SettingsArchive.read(from: root)
        let directory = root.appendingPathComponent("downloads", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let destination = try DownloadDirectory.select(directory)
        return Setup(root: selection.bookmark, downloads: destination.bookmark, name: root.lastPathComponent + "/downloads", restored: restored)
    }
}
