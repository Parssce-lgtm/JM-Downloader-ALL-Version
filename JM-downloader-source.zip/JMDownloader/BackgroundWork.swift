import BackgroundTasks
import UIKit

@MainActor
final class BackgroundWork {
    weak var store: AppStore?
    private var enabled = false
    private var continued: BGContinuedProcessingTask?
    private var processing: BGProcessingTask?
    private var requestID: String?
    private var jobIDs = Set<UUID>()
    private var processingID: String { (Bundle.main.bundleIdentifier ?? "app.jmdownloader.jmdownloader") + ".processing" }
    var hasExecutionTime: Bool { continued != nil || processing != nil }

    func register() {
        guard !enabled else { return }
        // BGTaskScheduler does not execute these tasks in Simulator.
        #if !targetEnvironment(simulator)
        enabled = BGTaskScheduler.shared.register(forTaskWithIdentifier: processingID, using: .main) { [weak self] task in
            guard let task = task as? BGProcessingTask else { task.setTaskCompleted(success: false); return }
            Task { @MainActor in
                guard let self, let store = self.store else { task.setTaskCompleted(success: false); return }
                self.processing = task
                task.expirationHandler = { [weak self] in
                    Task { @MainActor in
                        guard let self, self.processing === task else { return }
                        self.processing = nil
                        store.engine.suspendLocalWork()
                        task.setTaskCompleted(success: false)
                        self.scheduleRecovery()
                    }
                }
                store.start()
                store.engine.resumeAutomatic()
                store.engine.pump()
            }
        }
        #endif
    }
    func beginUserWork() {
        guard enabled, UIApplication.shared.applicationState == .active, let store else { return }
        jobIDs.formUnion(store.jobs.filter { $0.state.isRunning }.map(\.id))
        guard !jobIDs.isEmpty else { return }
        if requestID != nil { refresh(); return }
        let identifier = (Bundle.main.bundleIdentifier ?? "app.jmdownloader.jmdownloader") + ".continued." + UUID().uuidString
        // Register the concrete identifier to avoid wildcard handler matching ambiguity.
        guard BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: .main, launchHandler: { [weak self] task in
            guard let task = task as? BGContinuedProcessingTask else { task.setTaskCompleted(success: false); return }
            Task { @MainActor in
                guard let self, self.requestID == identifier else { task.setTaskCompleted(success: false); return }
                self.continued = task
                task.expirationHandler = { [weak self] in
                    Task { @MainActor in
                        guard let self, self.requestID == identifier else { return }
                        // The same callback is used for system expiration and the person's Stop action.
                        // Respect Stop: do not silently restart this particular continued task.
                        self.continued = nil; self.requestID = nil
                        let ids = self.jobIDs; self.jobIDs = []
                        self.store?.engine.pauseAll(ids: ids)
                        task.setTaskCompleted(success: false)
                        self.store?.log("系统后台任务已停止，进度已保留；可在下载任务中点全部开始继续。")
                    }
                }
                self.store?.engine.resumeAutomatic()
                self.store?.engine.pump()
                self.refresh()
            }
        }) else { store.log("系统未接受持续后台任务，图片仍由系统下载，PDF 将在可执行时继续。"); return }
        requestID = identifier
        let request = BGContinuedProcessingTaskRequest(identifier: identifier, title: "JM downloader", subtitle: "下载漫画并生成 PDF")
        request.strategy = .queue
        do { try BGTaskScheduler.shared.submit(request) }
        catch {
            requestID = nil
            store.log("持续后台任务暂不可用，已保留下载进度并使用系统后台调度。")
            scheduleRecovery()
        }
    }
    func refresh() {
        guard let store, store.engine.isReady else { return }
        let work = store.jobs.filter { jobIDs.contains($0.id) }
        if let continued {
            continued.progress.totalUnitCount = Int64(max(1, work.count) * 1000)
            continued.progress.completedUnitCount = work.reduce(0) { $0 + $1.workUnits }
            let exports = work.filter { $0.state == .exporting }.count
            let completed = work.filter { $0.state == .completed }.count
            continued.updateTitle("JM downloader", subtitle: exports > 0 ? "正在生成 PDF · 已完成 \(completed)/\(work.count) 部" : "正在下载 · 已完成 \(completed)/\(work.count) 部")
        }
        if requestID != nil, !work.contains(where: { $0.state.isRunning || $0.resumeAutomatically == true }) {
            continued?.setTaskCompleted(success: !work.isEmpty && work.allSatisfy { $0.state == .completed })
            if let requestID { BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: requestID) }
            continued = nil; requestID = nil; jobIDs = []
        }
        if let processing, !store.jobs.contains(where: { $0.state.isRunning || $0.resumeAutomatically == true }) {
            processing.setTaskCompleted(success: true); self.processing = nil
        }
    }
    func scheduleRecovery() {
        guard enabled, let store else { return }
        let jobs = store.jobs.filter { $0.state.isRunning || $0.resumeAutomatically == true }
        BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: processingID)
        guard !jobs.isEmpty else { return }
        let request = BGProcessingTaskRequest(identifier: processingID)
        request.requiresExternalPower = false
        request.requiresNetworkConnectivity = jobs.contains { $0.pages.isEmpty || $0.finished.count < $0.pages.count }
        request.earliestBeginDate = Date(timeIntervalSinceNow: 60)
        do { try BGTaskScheduler.shared.submit(request) }
        catch { store.log("系统未安排额外后台时间；下次返回应用会自动接续系统暂停的任务。") }
    }
}
