import Foundation
import UIKit
import ImageIO
import PDFKit

actor ImagePipeline {
    static let shared = ImagePipeline()

    static func decoded(_ data: Data, page: PageAsset) throws -> CGImage {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
            throw JMError.message("下载内容不是有效图片，请重试或更换图片域名。")
        }
        let filename = (page.filename as NSString).deletingPathExtension
        let strips = JMCrypto.strips(chapterID: Int(page.chapterID) ?? 0, filename: filename, scrambleID: page.scrambleID)
        guard strips > 0 else { return image }
        guard image.height >= strips, image.width <= 30000, image.height <= 100000,
              let context = CGContext(data: nil, width: image.width, height: image.height,
                                      bitsPerComponent: 8, bytesPerRow: 0, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { throw JMError.message("图片尺寸不受支持。") }
        for slice in JMCrypto.slices(height: image.height, count: strips) {
            guard let part = image.cropping(to: CGRect(x: 0, y: slice.source, width: image.width, height: slice.height)) else {
                throw JMError.message("图片解扰失败。")
            }
            // CGImage crops use top-left pixels; CGContext's default origin is bottom-left.
            context.draw(part, in: CGRect(x: 0, y: image.height - slice.destination - slice.height,
                                         width: image.width, height: slice.height))
        }
        guard let result = context.makeImage() else { throw JMError.message("图片合成失败。") }
        return result
    }

    func export(_ job: DownloadJob, bookmark: Data?) throws -> URL {
        var scoped = false
        var directory = DiskStore.documents
        if let bookmark {
            var stale = false
            directory = try URL(resolvingBookmarkData: bookmark, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
            scoped = directory.startAccessingSecurityScopedResource()
            guard scoped else { throw JMError.message("下载目录授权已失效，请重新选择目录。") }
        }
        defer { if scoped { directory.stopAccessingSecurityScopedResource() } }
        let fm = FileManager.default
        try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        let name = Validation.safeName(job.comic.title) + " [\(job.comic.id)]"
        let output = directory.appendingPathComponent(name + ".pdf")
        let temporary = directory.appendingPathComponent(".\(job.id.uuidString).partial.pdf")
        defer { try? fm.removeItem(at: temporary) }
        guard let consumer = CGDataConsumer(url: temporary as CFURL),
              let context = CGContext(consumer: consumer, mediaBox: nil, nil) else { throw JMError.message("无法创建 PDF，请检查目录权限。") }
        do {
            for (index, page) in job.pages.enumerated() {
                try Task.checkCancellation()
                try autoreleasepool {
                    let image: CGImage
                    do { image = try Self.decoded(Data(contentsOf: DiskStore.raw(job.id, index)), page: page) }
                    catch { try? fm.removeItem(at: DiskStore.raw(job.id, index)); throw error }
                    let scale = min(1, 14000 / Double(max(image.width, image.height)))
                    var bounds = CGRect(x: 0, y: 0, width: Double(image.width) * scale, height: Double(image.height) * scale)
                    let box = NSData(bytes: &bounds, length: MemoryLayout<CGRect>.size)
                    context.beginPDFPage([kCGPDFContextMediaBox as String: box] as CFDictionary)
                    context.draw(image, in: bounds)
                    context.endPDFPage()
                }
            }
            context.closePDF()
        } catch { context.closePDF(); throw error }
        guard let pdf = CGPDFDocument(temporary as CFURL), pdf.numberOfPages == job.pages.count else {
            throw JMError.message("PDF 完整性校验失败，缓存已保留。")
        }
        if fm.fileExists(atPath: output.path) { _ = try fm.replaceItemAt(output, withItemAt: temporary) }
        else { try fm.moveItem(at: temporary, to: output) }
        return output
    }
}
