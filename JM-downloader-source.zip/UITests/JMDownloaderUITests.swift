import XCTest

final class JMDownloaderUITests: XCTestCase {
    @MainActor func testRecommendationLoadingAndDisconnectedStatus() {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-fixture-v120", "--recommendation-loading-fixture", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.segmentedControls["libraryTabs"].waitForExistence(timeout: 10))
        app.segmentedControls["libraryTabs"].buttons["漫画推荐"].tap()
        XCTAssertTrue(app.staticTexts["librarySearching"].waitForExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["librarySearching"].label, "正在搜索…")
        attach(app, name: "20-recommendations-searching")
        app.terminate()
        app.launchArguments = ["--ui-fixture-v120", "--recommendation-failure-fixture", "--dark-fixture", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.segmentedControls["libraryTabs"].waitForExistence(timeout: 10))
        app.segmentedControls["libraryTabs"].buttons["漫画推荐"].tap()
        XCTAssertTrue(app.staticTexts["libraryDisconnected"].waitForExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["libraryDisconnected"].label, "网络已断开")
        XCTAssertFalse(app.staticTexts["libraryEmpty"].exists)
        XCTAssertTrue(app.buttons["retryLibrary"].isHittable)
        XCTAssertFalse(app.alerts.firstMatch.exists)
        attach(app, name: "21-recommendations-disconnected-dark")
    }
    @MainActor func testFavoriteAndRecommendationBottomRowsRemainReachable() {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-fixture-v120", "--long-library-fixture", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.segmentedControls["libraryTabs"].waitForExistence(timeout: 10))
        for module in ["漫画收藏", "漫画推荐"] {
            app.segmentedControls["libraryTabs"].buttons[module].tap()
            let scroll = app.scrollViews["libraryScroll-" + module]
            let lastCover = app.buttons["cover-10035"]
            for _ in 0..<12 { if lastCover.isHittable { break }; scroll.swipeUp() }
            // Scroll to the actual bottom, then verify the complete card clears
            // the home-indicator region and its action can still be tapped.
            scroll.swipeUp()
            XCTAssertTrue(lastCover.isHittable)
            XCTAssertLessThan(lastCover.frame.maxY, app.frame.maxY - 20)
            attach(app, name: "22-bottom-clear-" + module)
            lastCover.tap()
            XCTAssertTrue(app.navigationBars["封面详情"].waitForExistence(timeout: 5))
            app.buttons["完成"].tap()
        }
    }
    @MainActor func testProgressLogsRemainTouchableAndCanPause() {
        let app = XCUIApplication()
        app.launchArguments += ["--ui-fixture-v120", "--progress-stress-fixture", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.segmentedControls["libraryTabs"].waitForExistence(timeout: 10))
        app.segmentedControls["libraryTabs"].buttons["下载任务"].tap()
        app.buttons["logCapsule"].tap()
        XCTAssertTrue(app.buttons["closeLogHistory"].waitForExistence(timeout: 5))
        attach(app, name: "19-log-history-during-pdf-progress")
        app.buttons["closeLogHistory"].tap()
        XCTAssertTrue(app.buttons["pauseAll"].waitForExistence(timeout: 5))
        app.buttons["pauseAll"].tap()
        app.buttons["settings"].tap()
        XCTAssertTrue(app.buttons["accountSettings"].waitForExistence(timeout: 5))
    }
    @MainActor func testCreateAndSelectDownloadDirectory() {
        let app = XCUIApplication()
        app.launchArguments += ["--ui-fixture-v120", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.buttons["settings"].waitForExistence(timeout: 10))
        app.buttons["settings"].tap(); app.buttons["accountSettings"].tap()
        let directoryLink = app.buttons["downloadDirectorySettings"]
        for _ in 0..<5 { if directoryLink.isHittable { break }; app.swipeUp() }
        directoryLink.tap()
        let field = app.textFields["newDownloadFolderName"]
        for _ in 0..<5 { if field.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(field.isHittable)
        field.tap(); field.typeText("UI-PDF-" + String(Int(Date().timeIntervalSince1970)))
        app.buttons["createDownloadFolder"].tap()
        XCTAssertTrue(app.staticTexts["directoryNotice"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["directoryNotice"].label.contains("已选择"))
        attach(app, name: "20-new-download-directory")
        app.buttons["chooseDownloadDirectory"].tap()
        XCTAssertTrue(app.buttons["打开"].waitForExistence(timeout: 10))
        attach(app, name: "21-native-folder-picker")
        app.buttons["打开"].tap()
        XCTAssertTrue(app.buttons["chooseDownloadDirectory"].waitForExistence(timeout: 10))
        XCTAssertTrue(app.staticTexts["directoryNotice"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["directoryNotice"].label.contains("已选择"))
        app.navigationBars["下载目录"].buttons["BackButton"].tap()
        app.buttons["saveAccount"].tap()
        XCTAssertTrue(app.buttons["settings"].waitForExistence(timeout: 5))
    }
    @MainActor func testQueueLibraryAndNearbyDeletion() {
        let app = XCUIApplication()
        app.launchArguments += ["--ui-fixture-v120", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        let tabs = app.segmentedControls["libraryTabs"]
        XCTAssertTrue(tabs.waitForExistence(timeout: 10))
        XCTAssertLessThan(tabs.buttons["下载任务"].frame.minX, tabs.buttons["漫画收藏"].frame.minX)
        XCTAssertFalse(app.descendants(matching: .any)["downloaded-10001"].exists)
        app.buttons["下载 等待继续的漫画"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["downloading-10003"].waitForExistence(timeout: 2))
        attach(app, name: "12-favorites-collapsed")
        app.buttons["更多"].tap()
        XCTAssertTrue(app.buttons["查看已下载"].waitForExistence(timeout: 3))
        app.buttons["查看已下载"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["downloaded-10001"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["下载 已保存的漫画"].exists)
        attach(app, name: "08-library-downloaded")
        tabs.buttons["漫画推荐"].tap()
        XCTAssertTrue(app.buttons["recommendationSort"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["openComicSearch"].exists)
        XCTAssertFalse(app.descendants(matching: .any)["downloaded-10001"].exists)
        app.buttons["recommendationSort"].tap()
        for title in ["最新", "最多爱心", "最多点击", "最多查看"] { XCTAssertTrue(app.buttons[title].exists) }
        attach(app, name: "13-recommendation-sorting")
        app.buttons["最多爱心"].tap()
        tabs.buttons["下载任务"].tap()
        XCTAssertFalse(app.buttons["搜索"].exists)
        XCTAssertFalse(app.buttons["更多"].exists)
        XCTAssertTrue(app.buttons["startAll"].waitForExistence(timeout: 5))
        XCTAssertLessThan(app.staticTexts["正在下载的漫画"].frame.minY, app.staticTexts["等待继续的漫画"].frame.minY)
        attach(app, name: "09-queue-priority")
        app.buttons["pauseAll"].tap()
        XCTAssertFalse(app.staticTexts["下载中"].exists)
        app.buttons["startAll"].tap()
        XCTAssertTrue(app.staticTexts["等待下载"].firstMatch.waitForExistence(timeout: 5))
        let card = app.staticTexts["等待继续的漫画"]
        let originalY = card.frame.midY
        let deleteAction = app.buttons["删除任务及下载缓存"]
        card.press(forDuration: 1.5)
        // Simulator context menus may miss the first press during a row reorder.
        // Retry the gesture once only if the menu never appeared; still require it.
        if !deleteAction.waitForExistence(timeout: 4) { card.press(forDuration: 1.5) }
        XCTAssertTrue(deleteAction.waitForExistence(timeout: 5))
        deleteAction.tap()
        XCTAssertTrue(app.buttons["confirmDelete"].waitForExistence(timeout: 5))
        XCTAssertLessThan(abs(app.buttons["confirmDelete"].frame.midY - originalY), 330)
        attach(app, name: "10-delete-near-card")
        app.buttons["confirmDelete"].tap()
        XCTAssertTrue(app.staticTexts["等待继续的漫画"].waitForNonExistence(timeout: 5))
        app.buttons["settings"].tap()
        app.buttons["cacheSettings"].tap()
        app.buttons["clearCoverCache"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["cacheNotice"].waitForExistence(timeout: 5))
        attach(app, name: "11-cache-cleared")
    }
    @MainActor func testSwipeSearchHidingAndAutomaticDownloadMenu() {
        let app = XCUIApplication()
        app.launchArguments += ["--ui-fixture-v120", "--dark-fixture", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        let tabs = app.segmentedControls["libraryTabs"]
        XCTAssertTrue(tabs.waitForExistence(timeout: 10))
        let favorite = app.staticTexts["等待继续的漫画"]
        favorite.press(forDuration: 1)
        XCTAssertFalse(app.buttons["不再自动下载"].exists)
        XCTAssertFalse(app.buttons["删除任务及下载缓存"].exists)
        app.buttons["隐藏漫画"].tap()
        XCTAssertTrue(favorite.waitForNonExistence(timeout: 3))
        app.buttons["更多"].tap(); app.buttons["查看隐藏漫画"].tap()
        XCTAssertTrue(favorite.waitForExistence(timeout: 3))
        favorite.press(forDuration: 1)
        app.buttons["取消隐藏漫画"].tap()
        // Swipe across otherwise empty content below the tabs.
        let left = app.coordinate(withNormalizedOffset: CGVector(dx: 0.15, dy: 0.6))
        let right = app.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.6))
        right.press(forDuration: 0.05, thenDragTo: left)
        XCTAssertTrue(app.buttons["recommendationSort"].waitForExistence(timeout: 3))
        app.buttons["openComicSearch"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        app.textFields["comicSearchField"].typeText("AI")
        app.buttons["submitComicSearch"].tap()
        XCTAssertTrue(app.staticTexts["主动搜索的 AI 漫画"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.descendants(matching: .any)["downloaded-10001"].exists)
        attach(app, name: "14-dark-search-blacklist-bypass")
        left.press(forDuration: 0.05, thenDragTo: right)
        XCTAssertTrue(app.buttons["openComicSearch"].waitForExistence(timeout: 3))
        XCTAssertTrue(tabs.buttons["漫画收藏"].isSelected)
        left.press(forDuration: 0.05, thenDragTo: right)
        XCTAssertTrue(app.buttons["startAll"].waitForExistence(timeout: 3))
        let task = app.staticTexts["等待继续的漫画"]
        task.press(forDuration: 1)
        XCTAssertFalse(app.buttons["下载漫画"].exists)
        // The card still has a play button; only the context-menu action was removed.
        app.buttons["不再自动下载"].tap()
        task.press(forDuration: 1)
        XCTAssertTrue(app.buttons["开启自动下载"].waitForExistence(timeout: 3))
        XCTAssertFalse(app.buttons["不再自动下载"].exists)
        app.buttons["开启自动下载"].tap()
        attach(app, name: "15-dark-queue-bordered-cards-capsule")
    }
    @MainActor func testSingleTapCoverAndSearchDismissal() {
        let app = XCUIApplication()
        app.launchArguments += ["--ui-fixture-v120", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        let tabs = app.segmentedControls["libraryTabs"]
        XCTAssertTrue(tabs.waitForExistence(timeout: 10))
        for module in ["漫画收藏", "下载任务", "漫画推荐"] {
            tabs.buttons[module].tap()
            let cover = app.buttons["cover-10003"]
            XCTAssertTrue(cover.waitForExistence(timeout: 5))
            cover.tap()
            XCTAssertTrue(app.navigationBars["封面详情"].waitForExistence(timeout: 5))
            attach(app, name: "16-single-tap-cover-" + module)
            app.buttons["完成"].tap()
            XCTAssertTrue(app.navigationBars["封面详情"].waitForNonExistence(timeout: 5))
        }
        app.buttons["openComicSearch"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        app.textFields["comicSearchField"].typeText("AI")
        app.navigationBars["JM downloader"].staticTexts["JM downloader"].tap()
        XCTAssertTrue(app.textFields["comicSearchField"].waitForNonExistence(timeout: 3))
        XCTAssertTrue(app.staticTexts["等待继续的漫画"].exists)
        app.buttons["openComicSearch"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        app.buttons["submitComicSearch"].tap()
        XCTAssertTrue(app.staticTexts["主动搜索的 AI 漫画"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.descendants(matching: .any)["downloaded-10001"].exists)
        XCTAssertFalse(app.textFields["comicSearchField"].exists)
        XCTAssertTrue(app.buttons["exitComicSearch"].exists)
        attach(app, name: "17-search-results-keyboard-dismissed")
        app.buttons["exitComicSearch"].tap()
        XCTAssertTrue(app.staticTexts["等待继续的漫画"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["主动搜索的 AI 漫画"].exists)
        attach(app, name: "18-restored-recommendations")
    }
    @MainActor func testSettingsAndSelectionFlow() {
        let app = XCUIApplication()
        app.launchArguments += ["-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.buttons["settings"].waitForExistence(timeout: 10))
        attach(app, name: "01-home-iPhone-17-Pro-Max")
        app.buttons["settings"].tap()
        XCTAssertTrue(app.buttons["accountSettings"].waitForExistence(timeout: 5))
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.switches["记住账号"].waitForExistence(timeout: 5))
        attach(app, name: "02-account-settings")
        app.segmentedControls["platformPicker"].buttons["PicACG"].tap()
        XCTAssertTrue(app.buttons["登录 PicACG"].exists)
        let username = app.textFields["账号"]
        username.tap(); username.typeText("keyboard-fixture")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        app.navigationBars["账号设置"].staticTexts["账号设置"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 3))
        attach(app, name: "03-picacg-settings")
        app.swipeUp()
        app.buttons["saveNetwork"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["networkNotice"].waitForExistence(timeout: 3))
        attach(app, name: "06-network-saved")
        app.buttons["saveAccount"].tap()
        XCTAssertTrue(app.navigationBars["账号设置"].waitForNonExistence(timeout: 5))
        app.buttons["settings"].tap()
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.segmentedControls["platformPicker"].buttons["PicACG"].isSelected)
        app.buttons["saveAccount"].tap()
        app.terminate(); app.launch()
        app.buttons["settings"].tap()
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.segmentedControls["platformPicker"].buttons["PicACG"].isSelected)
        app.navigationBars["账号设置"].buttons["BackButton"].tap()
        app.buttons["themeSettings"].tap()
        XCTAssertEqual(app.buttons["theme-橙"].value as? String, "已选择")
        attach(app, name: "07-theme-unchanged-orange")
        app.navigationBars["主题设置"].buttons["BackButton"].tap()
        app.buttons["themeSettings"].tap()
        XCTAssertEqual(app.buttons["theme-橙"].value as? String, "已选择")
        app.buttons["theme-蓝"].tap()
        XCTAssertEqual(app.buttons["theme-蓝"].value as? String, "已选择")
        attach(app, name: "04-theme-blue")
        app.segmentedControls.buttons["深色"].tap()
        attach(app, name: "05-theme-dark")
    }
    @MainActor private func attach(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
}
