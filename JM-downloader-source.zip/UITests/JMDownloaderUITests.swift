import XCTest

final class JMDownloaderUITests: XCTestCase {
    @MainActor func testSettingsAndSelectionFlow() {
        let app = XCUIApplication()
        app.launchArguments += ["-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.buttons["settings"].waitForExistence(timeout: 10))
        attach(app, name: "01-home-iPhone-17-Pro-Max")
        app.buttons["settings"].tap()
        XCTAssertTrue(app.buttons["accountSettings"].waitForExistence(timeout: 5))
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.switches["记住账号"].waitForExistence(timeout: 5))
        attach(app, name: "02-account-settings")
    }
    @MainActor private func attach(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
}
