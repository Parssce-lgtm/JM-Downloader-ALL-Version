import XCTest

final class JMDownloaderUITests: XCTestCase {
    @MainActor func testSettingsAndSelectionFlow() {
        let app = XCUIApplication()
        app.launchArguments += ["-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.buttons["settings"].waitForExistence(timeout: 10))
        attach(app, name: "01-home-iPhone-17-Pro-Max")
        app.buttons["settings"].tap()
        XCTAssertTrue(app.buttons["accountSettings"].waitForExistence(timeout: 5))
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.switches["记住账号"].waitForExistence(timeout: 5))
        attach(app, name: "02-account-settings")
        app.segmentedControls["platformPicker"].buttons["PicACG"].tap()
        XCTAssertTrue(app.buttons["登录 PicACG"].exists)
        let username = app.textFields["账号"]
        username.tap(); username.typeText("keyboard-fixture")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 3))
        app.navigationBars["账号设置"].staticTexts["账号设置"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 3))
        attach(app, name: "03-picacg-settings")
        app.swipeUp()
        app.buttons["saveNetwork"].tap()
        XCTAssertTrue(app.descendants(matching: .any)["networkNotice"].waitForExistence(timeout: 3))
        attach(app, name: "06-network-saved")
        app.buttons["saveAccount"].tap()
        XCTAssertTrue(app.navigationBars["账号设置"].waitForNonExistence(timeout: 5))
        app.buttons["settings"].tap()
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.segmentedControls["platformPicker"].buttons["PicACG"].isSelected)
        app.buttons["saveAccount"].tap()
        app.terminate(); app.launch()
        app.buttons["settings"].tap()
        app.buttons["accountSettings"].tap()
        XCTAssertTrue(app.segmentedControls["platformPicker"].buttons["PicACG"].isSelected)
        app.navigationBars["账号设置"].buttons["BackButton"].tap()
        app.buttons["themeSettings"].tap()
        XCTAssertEqual(app.buttons["theme-橙"].value as? String, "已选择")
        attach(app, name: "07-theme-unchanged-orange")
        app.navigationBars["主题设置"].buttons["BackButton"].tap()
        app.buttons["themeSettings"].tap()
        XCTAssertEqual(app.buttons["theme-橙"].value as? String, "已选择")
        app.buttons["theme-蓝"].tap()
        XCTAssertEqual(app.buttons["theme-蓝"].value as? String, "已选择")
        attach(app, name: "04-theme-blue")
        app.segmentedControls.buttons["深色"].tap()
        attach(app, name: "05-theme-dark")
    }
    @MainActor private func attach(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
}
